package com.nextlesson.app

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

/**
 * Редактор виджета: положение текстов и картинок/гифок.
 * Сверху — копия виджета, на ней всё можно перетаскивать пальцем.
 * Снизу — 8 стрелок для точной подстройки.
 */
class EditorActivity : Activity() {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val handler = Handler(Looper.getMainLooper())

    private var tab = 0            // 0 = тексты, 1 = картинки и гифки
    private var selText = 0
    private var selSlot = 0
    private var wDp = 320
    private var hDp = 200
    private var grad: Grad = Themes.DEFAULT
    private var pendingSlot = 0

    private lateinit var tabsRow: LinearLayout
    private lateinit var previewBox: FrameLayout
    private lateinit var mid: LinearLayout
    private lateinit var selLabel: TextView

    private var master: WidgetPreview? = null
    private val minis = HashMap<Int, WidgetPreview>()
    private val chips = HashMap<Int, TextView>()
    private val cards = HashMap<Int, LinearLayout>()

    private val pushWidget = Runnable { WidgetUpdater.updateAll(this@EditorActivity) }

    // повтор при удержании стрелки
    private var repDx = 0
    private var repDy = 0
    private var repTicks = 0
    private val repeater = object : Runnable {
        override fun run() {
            repTicks++
            val step = if (repTicks < 12) 1f else if (repTicks < 30) 2f else 3f
            nudgeSel(repDx * step, repDy * step)
            handler.postDelayed(this, 35)
        }
    }

    private val previewListener = object : WidgetPreview.Listener {
        override fun onSelect(isText: Boolean, id: Int) {
            if (isText) selText = id else selSlot = id
            master?.select(isText, id, false)
            styleChips()
            styleCards()
            refreshSelLabel()
        }

        override fun onMove(isText: Boolean, id: Int, x: Float, y: Float) {
            master?.setPos(isText, id, x, y)
            if (!isText) minis[id]?.setPos(false, id, x, y)
        }

        override fun onCommit(isText: Boolean, id: Int, x: Float, y: Float) {
            savePos(isText, id, x, y)
        }
    }

    // ───────────────────────── жизненный цикл ─────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        C.apply(Store.uiGrad(this))
        grad = Store.grad(this)
        val sz = WidgetUpdater.widgetSizeDp(this)
        wDp = sz.first
        hDp = sz.second
        tab = intent.getIntExtra("tab", 0).coerceIn(0, 1)
        build()
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(repeater)
        handler.removeCallbacks(pushWidget)
        WidgetUpdater.updateAll(this)
    }

    // ───────────────────────── helpers ─────────────────────────

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(fill: Int, radiusDp: Int, stroke: Int = 0, strokeDp: Int = 1): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(fill)
        d.cornerRadius = dp(radiusDp).toFloat()
        if (stroke != 0) d.setStroke(dp(strokeDp), stroke)
        return d
    }

    private fun ui(): Grad = Grad(Themes.lift(Store.uiGrad(this).c1), Themes.lift(Store.uiGrad(this).c2), 0)

    private fun gradient(radiusDp: Int): GradientDrawable {
        val u = ui()
        val d = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(u.c1, u.c2))
        d.cornerRadius = dp(radiusDp).toFloat()
        return d
    }

    private fun onPrimary(): Int = Themes.textColor(ui())

    private fun text(s: String, sizeSp: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = sizeSp
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    private fun lp(top: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(MATCH, WRAP)
        p.topMargin = dp(top)
        return p
    }

    private fun btn(label: String, primary: Boolean, onClick: () -> Unit): TextView {
        val t = text(label, 14f, if (primary) onPrimary() else C.ACCENT, true)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(10), dp(11), dp(10), dp(11))
        t.background = if (primary) gradient(16) else rounded(C.CARD2, 16, C.STROKE)
        t.setOnClickListener { onClick() }
        return t
    }

    // ───────────────────────── экран ─────────────────────────

    private fun build() {
        window.statusBarColor = C.BG1
        window.navigationBarColor = C.BG1

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(C.BG1, C.BG2, C.BG1)
        )
        root.setPadding(dp(14), dp(36), dp(14), dp(10))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        val back = text("←", 22f, Color.WHITE, true)
        back.gravity = Gravity.CENTER
        back.background = rounded(C.CARD2, 16, C.STROKE)
        back.setOnClickListener { finish() }
        bar.addView(back, LinearLayout.LayoutParams(dp(44), dp(44)))
        val title = text("Редактор виджета", 20f, Color.WHITE, true)
        title.setPadding(dp(12), 0, 0, 0)
        bar.addView(title)
        root.addView(bar, lp(0))

        tabsRow = LinearLayout(this)
        tabsRow.orientation = LinearLayout.HORIZONTAL
        root.addView(tabsRow, lp(10))

        previewBox = FrameLayout(this)
        root.addView(previewBox, lp(10))

        val scroll = ScrollView(this)
        mid = LinearLayout(this)
        mid.orientation = LinearLayout.VERTICAL
        scroll.addView(mid)
        root.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))

        root.addView(buildPad(), lp(8))
        setContentView(root)
        renderTab()
    }

    private fun renderTabs() {
        tabsRow.removeAllViews()
        val labels = listOf("Текст", "Картинки и гифки")
        for (i in labels.indices) {
            val sel = tab == i
            val t = text(labels[i], 14f, if (sel) onPrimary() else C.MUTED, true)
            t.gravity = Gravity.CENTER
            t.setPadding(dp(8), dp(11), dp(8), dp(11))
            t.background = if (sel) gradient(16) else rounded(C.CARD2, 16, C.STROKE)
            t.setOnClickListener {
                tab = i
                renderTab()
            }
            val p = LinearLayout.LayoutParams(0, WRAP, 1f)
            if (i == 0) p.rightMargin = dp(8)
            tabsRow.addView(t, p)
        }
    }

    private fun renderTab() {
        renderTabs()
        previewBox.removeAllViews()
        mid.removeAllViews()
        minis.clear()
        chips.clear()
        cards.clear()

        val screenW = resources.displayMetrics.widthPixels
        val screenH = resources.displayMetrics.heightPixels
        var w = screenW - dp(28)
        val aspect = hDp.toFloat() / wDp
        val maxH = (screenH * 0.32f).toInt()
        if (w * aspect > maxH) w = (maxH / aspect).toInt()

        val m = WidgetPreview(this, wDp, hDp, w, grad, true, true, -1)
        m.dragMode = if (tab == 0) 1 else 2
        m.listener = previewListener
        m.select(tab == 0, if (tab == 0) selText else selSlot, false)
        previewBox.addView(m, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER_HORIZONTAL))
        master = m

        if (tab == 0) renderTextList() else renderSlots()
        refreshSelLabel()
    }

    // ───────────────────────── вкладка «Текст» ─────────────────────────

    private fun renderTextList() {
        mid.addView(
            text(
                "Нажми на любой текст в превью и тяни пальцем — он поедет куда угодно в пределах виджета. " +
                    "Для точной подстройки используй стрелки внизу (можно держать).",
                12f, C.MUTED
            ), lp(4)
        )
        var i = 0
        while (i < Elems.COUNT) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (k in 0 until 2) {
                val idx = i + k
                val chip = text(Elems.NAMES[idx], 14f, C.ACCENT, true)
                chip.gravity = Gravity.CENTER
                chip.setPadding(dp(8), dp(12), dp(8), dp(12))
                chip.setOnClickListener {
                    selText = idx
                    master?.select(true, idx, false)
                    styleChips()
                    refreshSelLabel()
                }
                chips[idx] = chip
                val p = LinearLayout.LayoutParams(0, WRAP, 1f)
                p.setMargins(dp(3), dp(4), dp(3), dp(4))
                row.addView(chip, p)
            }
            mid.addView(row, lp(0))
            i += 2
        }
        styleChips()
        mid.addView(btn("↺  Вернуть все тексты на места", false) {
            Store.resetTextPos(this, -1)
            WidgetUpdater.updateAll(this)
            renderTab()
        }, lp(10))
    }

    private fun styleChips() {
        for ((idx, chip) in chips) {
            val sel = idx == selText
            chip.setTextColor(if (sel) onPrimary() else C.ACCENT)
            chip.background = if (sel) gradient(14) else rounded(C.CARD2, 14, C.STROKE)
        }
    }

    // ───────────────────────── вкладка «Картинки» ─────────────────────────

    private fun renderSlots() {
        mid.addView(
            text(
                "До 10 картинок и гифок. Тяни картинку пальцем в превью выше или в окошке её слота — " +
                    "она встанет ровно туда, куда отпустишь, можно чуть за край виджета. " +
                    "Лучше брать PNG с прозрачным фоном.",
                12f, C.MUTED
            ), lp(4)
        )
        val screenW = resources.displayMetrics.widthPixels
        val miniW = ((screenW - dp(28) - dp(28)) * 0.8f).toInt()

        for (slot in 0 until Store.OVERLAY_SLOTS) {
            val ov = Store.overlay(this, slot)
            val c = LinearLayout(this)
            c.orientation = LinearLayout.VERTICAL
            c.setPadding(dp(14), dp(12), dp(14), dp(14))
            c.setOnClickListener { selectSlot(slot) }

            val status = if (ov == null) "пусто" else if (ov.gif) "GIF" else "картинка"
            c.addView(text("Слот ${slot + 1}: $status", 16f, Color.WHITE, true))

            if (ov != null) {
                val mini = WidgetPreview(this, wDp, hDp, miniW, grad, false, true, slot)
                mini.dragMode = 2
                mini.listener = previewListener
                mini.select(false, slot, false)
                minis[slot] = mini
                val mlp = LinearLayout.LayoutParams(WRAP, WRAP)
                mlp.gravity = Gravity.CENTER_HORIZONTAL
                mlp.topMargin = dp(8)
                c.addView(mini, mlp)
            }

            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            val pick = btn(if (ov == null) "Выбрать файл" else "Заменить", true) {
                selectSlot(slot)
                pickFile(slot)
            }
            val p1 = LinearLayout.LayoutParams(0, WRAP, 1f)
            if (ov != null) p1.rightMargin = dp(8)
            row.addView(pick, p1)
            if (ov != null) {
                val del = btn("Убрать", false) {
                    Store.clearOverlay(this, slot)
                    WidgetUpdater.updateAll(this)
                    renderTab()
                }
                row.addView(del, LinearLayout.LayoutParams(0, WRAP, 1f))
            }
            c.addView(row, lp(10))

            if (ov != null) {
                val sizeLabel = text("Размер: ${ov.size}% высоты виджета", 13f, C.MUTED)
                c.addView(sizeLabel, lp(10))
                val sb = SeekBar(this)
                sb.max = 90
                sb.progress = ov.size - 10
                sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                        sizeLabel.text = "Размер: ${p + 10}% высоты виджета"
                    }

                    override fun onStartTrackingTouch(s: SeekBar?) {
                        s?.parent?.requestDisallowInterceptTouchEvent(true)
                    }

                    override fun onStopTrackingTouch(s: SeekBar?) {
                        val cur = Store.overlay(this@EditorActivity, slot) ?: return
                        Store.saveOverlay(this@EditorActivity, cur.copy(size = (s?.progress ?: 50) + 10))
                        master?.reload()
                        minis[slot]?.reload()
                        WidgetUpdater.updateAll(this@EditorActivity)
                    }
                })
                c.addView(sb)
            }
            cards[slot] = c
            mid.addView(c, lp(10))
        }
        styleCards()
    }

    private fun styleCards() {
        for ((slot, c) in cards) {
            val sel = slot == selSlot
            c.background = rounded(C.CARD2, 16, if (sel) C.ACCENT else C.STROKE, if (sel) 2 else 1)
        }
    }

    private fun selectSlot(slot: Int) {
        selSlot = slot
        master?.select(false, slot, false)
        styleCards()
        refreshSelLabel()
    }

    private fun pickFile(slot: Int) {
        pendingSlot = slot
        try {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "image/*"
            startActivityForResult(i, 4000 + slot)
        } catch (e: Exception) {
            try {
                val i = Intent(Intent.ACTION_GET_CONTENT)
                i.type = "image/*"
                startActivityForResult(Intent.createChooser(i, "Выбери картинку или GIF"), 4000 + slot)
            } catch (e2: Exception) {
                Toast.makeText(this, "Не нашёл, чем выбрать файл", Toast.LENGTH_LONG).show()
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode < 4000 || requestCode >= 4000 + Store.OVERLAY_SLOTS) return
        val slot = requestCode - 4000
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        try {
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
            if (bytes == null || bytes.isEmpty()) {
                Toast.makeText(this, "Не удалось прочитать файл", Toast.LENGTH_LONG).show()
                return
            }
            if (bytes.size > 12 * 1024 * 1024) {
                Toast.makeText(this, "Файл слишком большой (максимум 12 МБ)", Toast.LENGTH_LONG).show()
                return
            }
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
            if (o.outWidth <= 0 || o.outHeight <= 0) {
                Toast.makeText(this, "Это не картинка", Toast.LENGTH_LONG).show()
                return
            }
            Store.overlayFile(this, slot).writeBytes(bytes)
            val old = Store.overlay(this, slot)
            Store.saveOverlay(
                this,
                Store.Overlay(
                    slot, Overlays.isGif(bytes),
                    old?.cx ?: 0.5f, old?.cy ?: 0.5f,
                    old?.size ?: 40,
                    System.currentTimeMillis(),
                    o.outWidth.toFloat() / o.outHeight
                )
            )
            selSlot = slot
            WidgetUpdater.updateAll(this)
            renderTab()
        } catch (e: Exception) {
            Toast.makeText(this, "Не получилось добавить файл", Toast.LENGTH_LONG).show()
        }
    }

    // ───────────────────────── сохранение ─────────────────────────

    private fun savePos(isText: Boolean, id: Int, x: Float, y: Float) {
        if (isText) {
            Store.setTextPos(this, id, x, y)
        } else {
            val ov = Store.overlay(this, id) ?: return
            Store.saveOverlay(this, ov.copy(cx = x, cy = y))
        }
        // виджет обновляем не на каждый пиксель, а когда движение затихло
        handler.removeCallbacks(pushWidget)
        handler.postDelayed(pushWidget, 600)
    }

    // ───────────────────────── стрелки ─────────────────────────

    private fun refreshSelLabel() {
        selLabel.text = if (tab == 0) "Выбрано: " + Elems.NAMES[selText] else "Выбрано: слот ${selSlot + 1}"
    }

    private fun buildPad(): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.HORIZONTAL
        box.gravity = Gravity.CENTER_VERTICAL
        box.background = rounded(C.CARD, 20, C.STROKE)
        box.setPadding(dp(14), dp(8), dp(10), dp(8))

        val left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL
        selLabel = text("", 15f, Color.WHITE, true)
        left.addView(selLabel)
        left.addView(text("Стрелки двигают выбранное. Держи — поедет плавно. Центр — вернуть на место.", 12f, C.MUTED), lp(4))
        box.addView(left, LinearLayout.LayoutParams(0, WRAP, 1f))

        val grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL
        val labels = arrayOf("↖", "↑", "↗", "←", "↺", "→", "↙", "↓", "↘")
        val dxs = intArrayOf(-1, 0, 1, -1, 0, 1, -1, 0, 1)
        val dys = intArrayOf(-1, -1, -1, 0, 0, 0, 1, 1, 1)
        for (r in 0 until 3) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (k in 0 until 3) {
                val i = r * 3 + k
                val cell = text(labels[i], 20f, if (i == 4) onPrimary() else C.ACCENT, true)
                cell.gravity = Gravity.CENTER
                cell.background = if (i == 4) gradient(12) else rounded(C.CARD2, 12, C.STROKE)
                if (i == 4) {
                    cell.setOnClickListener { resetSel() }
                } else {
                    attachRepeat(cell, dxs[i], dys[i])
                }
                val p = LinearLayout.LayoutParams(dp(50), dp(42))
                p.setMargins(dp(2), dp(2), dp(2), dp(2))
                row.addView(cell, p)
            }
            grid.addView(row)
        }
        box.addView(grid)
        return box
    }

    private fun attachRepeat(v: View, dx: Int, dy: Int) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.alpha = 0.6f
                    repDx = dx
                    repDy = dy
                    repTicks = 0
                    nudgeSel(dx.toFloat(), dy.toFloat())
                    handler.removeCallbacks(repeater)
                    handler.postDelayed(repeater, 350)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.alpha = 1f
                    handler.removeCallbacks(repeater)
                }
            }
            true
        }
    }

    private fun nudgeSel(dxDp: Float, dyDp: Float) {
        master?.nudge(dxDp, dyDp)
    }

    private fun resetSel() {
        val m = master ?: return
        if (tab == 0) {
            Store.resetTextPos(this, selText)
            val p = Store.textPos(this, selText)
            m.setPos(true, selText, p.first, p.second)
        } else {
            val ov = Store.overlay(this, selSlot) ?: return
            Store.saveOverlay(this, ov.copy(cx = 0.5f, cy = 0.5f))
            m.setPos(false, selSlot, 0.5f, 0.5f)
            minis[selSlot]?.setPos(false, selSlot, 0.5f, 0.5f)
        }
        handler.removeCallbacks(pushWidget)
        handler.postDelayed(pushWidget, 400)
    }
}
