package com.nextlesson.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.Locale

/** Цвета приложения. Меняются через C.apply(...) в зависимости от выбранных «Цветов приложения». */
object C {
    private val D_BG1 = Color.parseColor("#0B0818")
    private val D_BG2 = Color.parseColor("#1B1033")
    private val D_CARD = Color.parseColor("#16102B")
    private val D_CARD2 = Color.parseColor("#1D1538")
    private val D_STROKE = Color.parseColor("#3D2E6B")
    private val D_ACCENT = Color.parseColor("#B79CFF")
    private val D_MUTED = Color.parseColor("#9A90BE")
    private val D_PILL = Color.parseColor("#33A78BFA")
    val V1 = Color.parseColor("#8B5CF6")
    val V2 = Color.parseColor("#C084FC")
    val DANGER = Color.parseColor("#FF8FA3")
    val GREEN = Color.parseColor("#6EE7B7")

    var BG1 = D_BG1
    var BG2 = D_BG2
    var CARD = D_CARD
    var CARD2 = D_CARD2
    var STROKE = D_STROKE
    var ACCENT = D_ACCENT
    var MUTED = D_MUTED
    var PILL = D_PILL

    /** Классический фиолетовый вид — по умолчанию. */
    val DEFAULT_UI = Grad(V1, V2, 0)

    fun apply(g: Grad) {
        if (g.c1 == V1 && g.c2 == V2) {
            BG1 = D_BG1; BG2 = D_BG2; CARD = D_CARD; CARD2 = D_CARD2
            STROKE = D_STROKE; ACCENT = D_ACCENT; MUTED = D_MUTED; PILL = D_PILL
            return
        }
        val p1 = Themes.lift(g.c1)
        val p2 = Themes.lift(g.c2)
        BG1 = Themes.mix(p1, Color.BLACK, 0.92f)
        BG2 = Themes.mix(p2, Color.BLACK, 0.86f)
        CARD = Themes.mix(p1, Color.BLACK, 0.88f)
        CARD2 = Themes.mix(p1, Color.BLACK, 0.80f)
        STROKE = Themes.mix(p1, Color.BLACK, 0.55f)
        ACCENT = Themes.mix(p2, Color.WHITE, 0.40f)
        MUTED = Themes.mix(ACCENT, BG2, 0.45f)
        PILL = Themes.withAlpha(p1, 0x40)
    }
}

/** Один урок. start/end — минуты от начала суток (08:30 = 510). */
data class Lesson(
    val name: String,
    val place: String,
    val start: Int,
    val end: Int,
    val kind: Int = 0   // 0 = обычное занятие (урок/пара/задача), 1 = встреча
)

/** Элементы текста на виджете, которые можно двигать. */
object Elems {
    const val COUNT = 6
    val NAMES = arrayOf("Заголовок", "Таймер", "Дата и время", "Название", "Кабинет / номер", "Заметка")

    /** Положение по умолчанию: левый верхний угол элемента в долях ширины/высоты виджета. */
    val DEF: Array<Pair<Float, Float>> = arrayOf(
        Pair(0.05f, 0.07f), Pair(0.50f, 0.06f), Pair(0.05f, 0.24f),
        Pair(0.05f, 0.33f), Pair(0.05f, 0.58f), Pair(0.05f, 0.76f)
    )
}

/** Градиент виджета. angle: 0 = слева направо, 90 = снизу вверх, 315 = из левого верхнего в правый нижний. */
data class Grad(val c1: Int, val c2: Int, val angle: Int)

data class Preset(val name: String, val c1: Int, val c2: Int)

object Themes {
    private fun p(n: String, a: String, b: String) = Preset(n, Color.parseColor(a), Color.parseColor(b))

    val PRESETS: List<Preset> = listOf(
        p("Ночь", "#241447", "#0D0A1C"),
        p("Фиолет", "#7F00FF", "#E100FF"),
        p("Океан", "#2193B0", "#6DD5ED"),
        p("Закат", "#FF512F", "#DD2476"),
        p("Персик", "#FF9966", "#FF5E62"),
        p("Лес", "#134E5E", "#71B280"),
        p("Мята", "#00B09B", "#96C93D"),
        p("Лаванда", "#667EEA", "#764BA2"),
        p("Индиго", "#8E2DE2", "#4A00E0"),
        p("Золото", "#F7971E", "#FFD200"),
        p("Небо", "#4776E6", "#8E54E9"),
        p("Роза", "#F953C6", "#B91D73"),
        p("Графит", "#232526", "#414345"),
        p("Космос", "#0F2027", "#2C5364"),
        p("Лёд", "#83A4D4", "#B6FBFF"),
        p("Лайм", "#A8E063", "#56AB2F"),
        p("Кофе", "#3E2723", "#8D6E63"),
        p("Огонь", "#F12711", "#F5AF19"),
        p("Сакура", "#FFAFBD", "#FFC3A0"),
        p("Уголь", "#000000", "#434343")
    )

    val DEFAULT = Grad(PRESETS[0].c1, PRESETS[0].c2, 315)

    private fun channel(v: Int): Double {
        val s = v / 255.0
        return if (s <= 0.03928) s / 12.92 else Math.pow((s + 0.055) / 1.055, 2.4)
    }

    fun lum(c: Int): Double =
        0.2126 * channel(Color.red(c)) + 0.7152 * channel(Color.green(c)) + 0.0722 * channel(Color.blue(c))

    fun isLight(g: Grad): Boolean = (lum(g.c1) + lum(g.c2)) / 2.0 > 0.25

    /** Цвет текста, читаемый на этом градиенте. */
    fun textColor(g: Grad): Int = if (isLight(g)) Color.parseColor("#1A1030") else Color.WHITE

    fun withAlpha(c: Int, a: Int): Int = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    fun mix(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) * (1 - t) + Color.red(b) * t).toInt(),
        (Color.green(a) * (1 - t) + Color.green(b) * t).toInt(),
        (Color.blue(a) * (1 - t) + Color.blue(b) * t).toInt()
    )

    /** Делает слишком тёмный цвет светлее, чтобы он был виден на тёмном фоне приложения. */
    fun lift(c: Int): Int {
        var x = c
        var i = 0
        while (lum(x) < 0.10 && i < 12) {
            x = mix(x, Color.WHITE, 0.15f)
            i++
        }
        return x
    }

    fun orientation(angle: Int): GradientDrawable.Orientation = when (((angle % 360) + 360) % 360) {
        0 -> GradientDrawable.Orientation.LEFT_RIGHT
        45 -> GradientDrawable.Orientation.BL_TR
        90 -> GradientDrawable.Orientation.BOTTOM_TOP
        135 -> GradientDrawable.Orientation.BR_TL
        180 -> GradientDrawable.Orientation.RIGHT_LEFT
        225 -> GradientDrawable.Orientation.TR_BL
        270 -> GradientDrawable.Orientation.TOP_BOTTOM
        else -> GradientDrawable.Orientation.TL_BR
    }

    fun drawable(g: Grad, radiusPx: Float, strokePx: Int = 0, strokeColor: Int = 0): GradientDrawable {
        val d = GradientDrawable(orientation(g.angle), intArrayOf(g.c1, g.c2))
        d.cornerRadius = radiusPx
        if (strokePx > 0) d.setStroke(strokePx, strokeColor)
        return d
    }

    /** Рисует скруглённый градиентный фон (для виджета). */
    fun drawBg(canvas: Canvas, w: Float, h: Float, g: Grad, r: Float) {
        val rad = Math.toRadians(g.angle.toDouble())
        val dx = Math.cos(rad).toFloat()
        val dy = (-Math.sin(rad)).toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val shader = LinearGradient(
            cx - dx * w / 2f, cy - dy * h / 2f, cx + dx * w / 2f, cy + dy * h / 2f,
            g.c1, g.c2, Shader.TileMode.CLAMP
        )
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = shader
        canvas.drawRoundRect(RectF(0f, 0f, w, h), r, r, p)
        val sw = maxOf(1f, r / 14f)
        val s = Paint(Paint.ANTI_ALIAS_FLAG)
        s.style = Paint.Style.STROKE
        s.strokeWidth = sw
        s.color = Color.argb(46, 255, 255, 255)
        canvas.drawRoundRect(RectF(sw / 2f, sw / 2f, w - sw / 2f, h - sw / 2f), r, r, s)
    }

    fun bitmap(wPx: Int, hPx: Int, g: Grad, r: Float): Bitmap {
        val b = Bitmap.createBitmap(maxOf(2, wPx), maxOf(2, hPx), Bitmap.Config.ARGB_8888)
        drawBg(Canvas(b), b.width.toFloat(), b.height.toFloat(), g, r)
        return b
    }
}

/**
 * Хранилище:
 *  - шаблон недели (1 = пн ... 7 = вс),
 *  - расписание на конкретные даты (перекрывает шаблон),
 *  - пропуски, заметка для виджета, цвета, часовой пояс.
 */
object Store {
    private fun prefs(c: Context) = c.getSharedPreferences("data", Context.MODE_PRIVATE)

    private fun readObj(c: Context, key: String): JSONObject {
        return try {
            JSONObject(prefs(c).getString(key, "{}") ?: "{}")
        } catch (e: Exception) {
            JSONObject()
        }
    }

    private fun parse(arr: JSONArray?): MutableList<Lesson> {
        val out = mutableListOf<Lesson>()
        if (arr == null) return out
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(Lesson(o.optString("n"), o.optString("p"), o.optInt("s"), o.optInt("e"), o.optInt("k", 0)))
        }
        out.sortBy { it.start }
        return out
    }

    private fun toArr(list: List<Lesson>): JSONArray {
        val arr = JSONArray()
        for (l in list.sortedBy { it.start }) {
            arr.put(JSONObject().put("n", l.name).put("p", l.place).put("s", l.start).put("e", l.end).put("k", l.kind))
        }
        return arr
    }

    // ── шаблон недели ──

    fun loadDay(c: Context, day: Int): MutableList<Lesson> =
        parse(readObj(c, "lessons").optJSONArray(day.toString()))

    fun saveDay(c: Context, day: Int, list: List<Lesson>) {
        val root = readObj(c, "lessons")
        root.put(day.toString(), toArr(list))
        prefs(c).edit().putString("lessons", root.toString()).apply()
    }

    // ── расписание на даты ──

    fun hasDate(c: Context, d: LocalDate): Boolean = readObj(c, "dates").has(d.toString())

    /** Все даты, на которые расписание записано вручную. */
    fun recordedDates(c: Context): Set<String> {
        val keys = HashSet<String>()
        val it = readObj(c, "dates").keys()
        while (it.hasNext()) keys.add(it.next())
        return keys
    }

    /** Уроки на дату: записанные вручную, а если их нет — по шаблону недели. */
    fun loadDate(c: Context, d: LocalDate): MutableList<Lesson> {
        val arr = readObj(c, "dates").optJSONArray(d.toString())
        return if (arr != null) parse(arr) else loadDay(c, d.dayOfWeek.value)
    }

    fun saveDate(c: Context, d: LocalDate, list: List<Lesson>) {
        val root = readObj(c, "dates")
        root.put(d.toString(), toArr(list))
        // чистим очень старые даты
        val limit = LocalDate.now().minusDays(120)
        val dead = ArrayList<String>()
        val it = root.keys()
        while (it.hasNext()) {
            val k = it.next()
            try {
                if (LocalDate.parse(k).isBefore(limit)) dead.add(k)
            } catch (e: Exception) {
                dead.add(k)
            }
        }
        for (k in dead) root.remove(k)
        prefs(c).edit().putString("dates", root.toString()).apply()
    }

    fun clearDate(c: Context, d: LocalDate) {
        val root = readObj(c, "dates")
        root.remove(d.toString())
        prefs(c).edit().putString("dates", root.toString()).apply()
    }

    // ── пропуски ──

    fun missed(c: Context): Set<String> {
        val out = HashSet<String>()
        try {
            val arr = JSONArray(prefs(c).getString("missed", "[]") ?: "[]")
            for (i in 0 until arr.length()) out.add(arr.optString(i))
        } catch (e: Exception) {
        }
        return out
    }

    fun toggleMissed(c: Context, key: String) {
        val s = HashSet(missed(c))
        if (!s.remove(key)) s.add(key)
        val arr = JSONArray()
        for (k in s.sorted()) arr.put(k)
        prefs(c).edit().putString("missed", arr.toString()).apply()
    }

    // ── заметка на виджете ──

    /** Удалять ли заметку, когда наступит следующий день. */
    fun noteExpires(c: Context): Boolean = prefs(c).getBoolean("note_exp", false)

    fun setNoteExpires(c: Context, v: Boolean) {
        prefs(c).edit().putBoolean("note_exp", v).apply()
    }

    /** Можно ли менять заметку, нажав на неё на виджете. */
    fun noteFromWidget(c: Context): Boolean = prefs(c).getBoolean("note_widget", true)

    fun setNoteFromWidget(c: Context, v: Boolean) {
        prefs(c).edit().putBoolean("note_widget", v).apply()
    }

    fun note(c: Context): String {
        val p = prefs(c)
        val n = p.getString("note", "") ?: ""
        if (n.isBlank()) return ""
        val today = LocalDate.now(zone(c))
        val day = p.getString("note_day", "") ?: ""
        if (day.isEmpty()) {
            p.edit().putString("note_day", today.toString()).apply()
            return n
        }
        if (noteExpires(c)) {
            val written = try {
                LocalDate.parse(day)
            } catch (e: Exception) {
                today
            }
            if (written.isBefore(today)) {
                p.edit().putString("note", "").putString("note_day", "").apply()
                return ""
            }
        }
        return n
    }

    fun setNote(c: Context, s: String) {
        prefs(c).edit()
            .putString("note", s.trim())
            .putString("note_day", LocalDate.now(zone(c)).toString())
            .apply()
    }

    // ── встречи ──

    /** Даты, на которые записана хотя бы одна встреча. */
    fun meetingDates(c: Context): Set<String> {
        val out = HashSet<String>()
        val root = readObj(c, "dates")
        val it = root.keys()
        while (it.hasNext()) {
            val k = it.next()
            val arr = root.optJSONArray(k) ?: continue
            for (i in 0 until arr.length()) {
                if (arr.optJSONObject(i)?.optInt("k", 0) == 1) {
                    out.add(k)
                    break
                }
            }
        }
        return out
    }

    // ── режим подписей (школьник, студент, дела, встречи ...) ──

    fun vocabId(c: Context): Int = prefs(c).getInt("vocab", 0)

    fun setVocab(c: Context, id: Int) {
        prefs(c).edit().putInt("vocab", id).apply()
    }

    // ── положение текстов на виджете ──

    fun textPos(c: Context, id: Int): Pair<Float, Float> {
        val def = Elems.DEF[id]
        val a = readObj(c, "tpos").optJSONArray(id.toString()) ?: return def
        if (a.length() < 2) return def
        return Pair(
            a.optDouble(0, def.first.toDouble()).toFloat(),
            a.optDouble(1, def.second.toDouble()).toFloat()
        )
    }

    fun setTextPos(c: Context, id: Int, x: Float, y: Float) {
        val root = readObj(c, "tpos")
        root.put(id.toString(), JSONArray().put(x.toDouble()).put(y.toDouble()))
        prefs(c).edit().putString("tpos", root.toString()).apply()
    }

    /** id < 0 — сбросить положение всех элементов. */
    fun resetTextPos(c: Context, id: Int) {
        if (id < 0) {
            prefs(c).edit().remove("tpos").apply()
            return
        }
        val root = readObj(c, "tpos")
        root.remove(id.toString())
        prefs(c).edit().putString("tpos", root.toString()).apply()
    }

    // ── картинки и гифки на виджете (до 10 штук) ──

    const val OVERLAY_SLOTS = 10

    /**
     * cx, cy — центр картинки в долях ширины и высоты виджета.
     * size — размер в % высоты виджета, ar — отношение ширины к высоте файла.
     */
    data class Overlay(
        val slot: Int,
        val gif: Boolean,
        val cx: Float,
        val cy: Float,
        val size: Int,
        val ts: Long,
        val ar: Float
    )

    fun overlayFile(c: Context, slot: Int): java.io.File = java.io.File(c.filesDir, "ov_$slot.bin")

    fun overlay(c: Context, slot: Int): Overlay? {
        val s = prefs(c).getString("ov$slot", null) ?: return null
        return try {
            val o = JSONObject(s)
            if (!overlayFile(c, slot).exists()) return null
            var cx = o.optDouble("x", Double.NaN).toFloat()
            var cy = o.optDouble("y", Double.NaN).toFloat()
            if (cx.isNaN() || cy.isNaN()) {
                // старый формат: 9 положений
                val a = o.optInt("anchor", 8)
                cx = floatArrayOf(0.16f, 0.5f, 0.84f)[a % 3]
                cy = floatArrayOf(0.22f, 0.5f, 0.78f)[a / 3]
            }
            var ar = o.optDouble("ar", 0.0).toFloat()
            if (ar <= 0f) ar = Overlays.aspect(overlayFile(c, slot))
            Overlay(slot, o.optBoolean("gif"), cx, cy, o.optInt("size", 60), o.optLong("ts"), ar)
        } catch (e: Exception) {
            null
        }
    }

    fun saveOverlay(c: Context, o: Overlay) {
        val j = JSONObject()
            .put("gif", o.gif)
            .put("x", o.cx.toDouble())
            .put("y", o.cy.toDouble())
            .put("size", o.size)
            .put("ts", o.ts)
            .put("ar", o.ar.toDouble())
        prefs(c).edit().putString("ov${o.slot}", j.toString()).apply()
    }

    fun clearOverlay(c: Context, slot: Int) {
        prefs(c).edit().remove("ov$slot").apply()
        try {
            overlayFile(c, slot).delete()
        } catch (e: Exception) {
        }
    }

    // ── цвета ──

    fun grad(c: Context): Grad {
        val p = prefs(c)
        if (!p.contains("g1")) return Themes.DEFAULT
        return Grad(p.getInt("g1", Themes.DEFAULT.c1), p.getInt("g2", Themes.DEFAULT.c2), p.getInt("gang", 315))
    }

    fun setGrad(c: Context, g: Grad) {
        prefs(c).edit().putInt("g1", g.c1).putInt("g2", g.c2).putInt("gang", g.angle).apply()
    }

    /** Цвета самого приложения (отдельно от цвета виджета). */
    fun uiGrad(c: Context): Grad {
        val p = prefs(c)
        if (!p.contains("u1")) return C.DEFAULT_UI
        return Grad(p.getInt("u1", C.V1), p.getInt("u2", C.V2), p.getInt("uang", 0))
    }

    fun setUiGrad(c: Context, g: Grad) {
        prefs(c).edit().putInt("u1", g.c1).putInt("u2", g.c2).putInt("uang", g.angle).apply()
    }

    // ── часовой пояс ──

    /** Пустая строка = часовой пояс устройства. */
    fun tzId(c: Context): String = prefs(c).getString("tz", "") ?: ""

    fun setTz(c: Context, id: String) {
        prefs(c).edit().putString("tz", id).apply()
    }

    fun zone(c: Context): ZoneId {
        val id = tzId(c)
        if (id.isBlank()) return ZoneId.systemDefault()
        return try {
            ZoneId.of(id)
        } catch (e: Exception) {
            ZoneId.systemDefault()
        }
    }
}

object Logic {
    val DAYS_FULL = arrayOf("Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье")
    val DAYS_SHORT = arrayOf("ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС")

    enum class Kind { CURRENT, NEXT, NONE }

    data class State(
        val kind: Kind,
        val lesson: Lesson?,
        val dayOffset: Int,      // 0 = сегодня, 1 = завтра ...
        val number: Int,         // номер среди занятий того же вида в этом дне
        val total: Int,          // сколько всего таких занятий в этом дне
        val date: LocalDate,     // дата
        val targetMs: Long,      // к какому моменту идёт таймер
        val refreshMs: Long,     // когда надо обновить виджет
        val hadToday: Boolean    // были ли сегодня занятия (и уже закончились)
    )

    fun hm(min: Int): String = String.format(Locale.ROOT, "%02d:%02d", min / 60, min % 60)

    fun dm(d: LocalDate): String = String.format(Locale.ROOT, "%02d.%02d", d.dayOfMonth, d.monthValue)

    private fun ms(date: LocalDate, minutes: Int, zone: ZoneId): Long {
        val m = minutes.coerceIn(0, 1439)
        return date.atTime(m / 60, m % 60).atZone(zone).toInstant().toEpochMilli()
    }

    private fun numOf(list: List<Lesson>, i: Int): Int = list.subList(0, i + 1).count { it.kind == list[i].kind }

    private fun totalOf(list: List<Lesson>, i: Int): Int = list.count { it.kind == list[i].kind }

    fun compute(c: Context, now: ZonedDateTime = ZonedDateTime.now(Store.zone(c))): State {
        val zone = now.zone
        val today = now.toLocalDate()
        val nowSec = now.toLocalTime().toSecondOfDay()
        val midnight = today.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
        val todayLessons = Store.loadDate(c, today)

        for ((i, l) in todayLessons.withIndex()) {
            if (nowSec >= l.start * 60 && nowSec < l.end * 60) {
                val end = ms(today, l.end, zone)
                return State(Kind.CURRENT, l, 0, numOf(todayLessons, i), totalOf(todayLessons, i), today, end, end, true)
            }
        }
        for ((i, l) in todayLessons.withIndex()) {
            if (nowSec < l.start * 60) {
                val start = ms(today, l.start, zone)
                return State(Kind.NEXT, l, 0, numOf(todayLessons, i), totalOf(todayLessons, i), today, start, start, i > 0)
            }
        }
        val had = todayLessons.isNotEmpty()
        for (off in 1..40) {
            val d = today.plusDays(off.toLong())
            val list = Store.loadDate(c, d)
            if (list.isNotEmpty()) {
                val l = list[0]
                return State(Kind.NEXT, l, off, 1, totalOf(list, 0), d, ms(d, l.start, zone), midnight, had)
            }
        }
        return State(Kind.NONE, null, 0, 0, 0, today, 0L, midnight, had)
    }

    /** Подписи для встречи всегда «встреча», для остального — выбранный режим. */
    fun vocabFor(c: Context, l: Lesson?): Vocab = if (l != null && l.kind == 1) Vocabs.MEETING else Vocabs.cur(c)

    fun header(c: Context, st: State): String {
        val cur = Vocabs.cur(c)
        val v = vocabFor(c, st.lesson)
        val s = when {
            st.kind == Kind.CURRENT -> "Сейчас " + v.nomSg
            st.kind == Kind.NONE -> "Расписание пусто"
            st.dayOffset == 0 -> Vocabs.nextTitle(v)
            st.hadToday -> cur.nomPl + " закончились"
            else -> "Сегодня " + cur.genPl + " нет"
        }
        return s.uppercase(Locale.ROOT)
    }

    fun countdownLabel(c: Context, st: State): String {
        val v = vocabFor(c, st.lesson)
        return if (st.kind == Kind.CURRENT) "До конца " + v.genSg else "До " + v.genSg
    }

    /** «первый урок», «вторая пара», «последняя встреча» ... */
    fun ordinal(c: Context, st: State): String =
        Vocabs.ordinal(vocabFor(c, st.lesson), st.number, st.total)

    fun whenText(st: State): String {
        val l = st.lesson ?: return ""
        val day = when (st.dayOffset) {
            0 -> "СЕГОДНЯ"
            1 -> "ЗАВТРА"
            else -> DAYS_SHORT[st.date.dayOfWeek.value - 1] + " " + dm(st.date)
        }
        return "$day · ${hm(l.start)}–${hm(l.end)}"
    }
}
