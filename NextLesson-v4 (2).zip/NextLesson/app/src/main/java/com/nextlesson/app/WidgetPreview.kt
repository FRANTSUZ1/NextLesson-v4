package com.nextlesson.app

import android.content.Context
import android.graphics.Color
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

/**
 * Копия виджета внутри приложения: фон, картинки и тексты стоят там же, где будут на виджете.
 * Размер настоящего виджета (wDp x hDp) пересчитывается под ширину экрана.
 * dragMode: 0 — смотреть, 1 — двигать тексты, 2 — двигать картинки.
 */
class WidgetPreview(
    ctx: Context,
    private val wDp: Int,
    private val hDp: Int,
    targetWidthPx: Int,
    private val grad: Grad,
    private val showTexts: Boolean,
    private val showOverlays: Boolean,
    private val onlySlot: Int          // -1 = все картинки, иначе только этот слот
) : FrameLayout(ctx) {

    interface Listener {
        fun onSelect(isText: Boolean, id: Int)
        fun onMove(isText: Boolean, id: Int, x: Float, y: Float)
        fun onCommit(isText: Boolean, id: Int, x: Float, y: Float)
    }

    var listener: Listener? = null
    var dragMode = 0

    private val dens = ctx.resources.displayMetrics.density
    private val wPx = (wDp * dens).toInt()
    private val hPx = (hDp * dens).toInt()
    private val scaleF = targetWidthPx / wPx.toFloat()
    private val viewW = (wPx * scaleF).toInt()
    private val viewH = (hPx * scaleF).toInt()
    private val canvasBox = FrameLayout(ctx)

    // тексты
    private val tx = FloatArray(Elems.COUNT)
    private val ty = FloatArray(Elems.COUNT)
    private val tw = IntArray(Elems.COUNT)
    private val th = IntArray(Elems.COUNT)
    private val textViews = arrayOfNulls<View>(Elems.COUNT)

    // картинки
    private val ovCx = FloatArray(Store.OVERLAY_SLOTS)
    private val ovCy = FloatArray(Store.OVERLAY_SLOTS)
    private val ovW = IntArray(Store.OVERLAY_SLOTS)
    private val ovH = IntArray(Store.OVERLAY_SLOTS)
    private val ovViews = arrayOfNulls<ImageView>(Store.OVERLAY_SLOTS)

    private val frame = View(ctx)
    var selIsText = true
        private set
    var selId = -1
        private set
    private var dragging = false
    private var lastX = 0f
    private var lastY = 0f

    init {
        addView(canvasBox)
        canvasBox.pivotX = 0f
        canvasBox.pivotY = 0f
        canvasBox.scaleX = scaleF
        canvasBox.scaleY = scaleF
        reload()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        canvasBox.measure(
            View.MeasureSpec.makeMeasureSpec(wPx, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(hPx, View.MeasureSpec.EXACTLY)
        )
        setMeasuredDimension(viewW, viewH)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        canvasBox.layout(0, 0, wPx, hPx)
    }

    // ───────────────────────── построение ─────────────────────────

    /** Перечитывает всё из хранилища (после смены картинки, размера, цвета). */
    fun reload() {
        canvasBox.removeAllViews()
        for (i in ovViews.indices) ovViews[i] = null
        for (i in textViews.indices) textViews[i] = null

        val bg = View(context)
        bg.background = Themes.drawable(
            grad, 22f * dens, maxOf(1, (1.2f * dens).toInt()), Color.argb(46, 255, 255, 255)
        )
        canvasBox.addView(bg, FrameLayout.LayoutParams(wPx, hPx))

        if (showOverlays) {
            for (slot in 0 until Store.OVERLAY_SLOTS) {
                if (onlySlot >= 0 && slot != onlySlot) continue
                val ov = Store.overlay(context, slot) ?: continue
                val bmp = Overlays.thumb(context, slot, ov.ts, 400) ?: continue
                val size = Overlays.dispSize(ov, wPx, hPx)
                val iv = ImageView(context)
                iv.scaleType = ImageView.ScaleType.FIT_XY
                iv.setImageBitmap(bmp)
                canvasBox.addView(iv, FrameLayout.LayoutParams(size.first, size.second))
                ovCx[slot] = ov.cx
                ovCy[slot] = ov.cy
                ovW[slot] = size.first
                ovH[slot] = size.second
                ovViews[slot] = iv
                placeOverlay(slot)
            }
        }
        if (showTexts) buildTexts()

        val fd = GradientDrawable()
        fd.setColor(Color.TRANSPARENT)
        fd.setStroke(maxOf(2, (2.2f * dens / scaleF).toInt()), Color.rgb(255, 214, 0))
        fd.cornerRadius = 6f * dens
        frame.background = fd
        frame.visibility = View.GONE
        canvasBox.addView(frame, FrameLayout.LayoutParams(1, 1))
        updateFrame()
    }

    private fun tv(text: String, sp: Float, color: Int, bold: Boolean): TextView {
        val t = TextView(context)
        t.text = text
        t.textSize = sp
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    private fun pad(v: View, h: Int, vv: Int) {
        v.setPadding((h * dens).toInt(), (vv * dens).toInt(), (h * dens).toInt(), (vv * dens).toInt())
    }

    private fun buildTexts() {
        val st = Logic.compute(context)
        val l = st.lesson
        val cur = Vocabs.cur(context)
        val tc = Themes.textColor(grad)
        val sec = Themes.withAlpha(tc, 0xCC)
        val pillRes = if (Themes.isLight(grad)) R.drawable.pill_dark else R.drawable.pill_light

        val headerS = if (l != null) Logic.header(context, st) else Vocabs.nextTitle(cur).uppercase(Locale.ROOT)
        val whenS = if (l != null) Logic.whenText(st) else "СЕГОДНЯ · 08:30–09:15"
        val labelS = if (l != null) Logic.countdownLabel(context, st) else "До " + cur.genSg
        val subjS = l?.name ?: "Название"
        val placeS = if (l != null) (if (l.place.isBlank()) Logic.ordinal(context, st) else l.place) else "Кабинет 257"
        val noteS = Store.note(context).ifBlank { "Взять тетрадь и ручку" }

        val views = arrayOfNulls<View>(Elems.COUNT)
        views[0] = tv(headerS, 12f, sec, true)

        val timer = LinearLayout(context)
        timer.orientation = LinearLayout.HORIZONTAL
        timer.gravity = android.view.Gravity.CENTER_VERTICAL
        timer.background = context.getDrawable(pillRes)
        pad(timer, 10, 3)
        timer.addView(tv(labelS, 11f, sec, false))
        val tt = tv("1:23:45", 12f, tc, true)
        val tlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        tlp.leftMargin = (5 * dens).toInt()
        timer.addView(tt, tlp)
        views[1] = timer

        views[2] = tv(whenS, 11f, sec, false)

        val sub = tv(subjS, 24f, tc, true)
        sub.maxLines = 2
        sub.ellipsize = TextUtils.TruncateAt.END
        views[3] = sub

        val pl = tv(placeS, 13f, tc, false)
        pl.background = context.getDrawable(pillRes)
        pad(pl, 12, 4)
        pl.maxLines = 1
        views[4] = pl

        val nt = tv("📝  $noteS", 12f, tc, false)
        nt.background = context.getDrawable(pillRes)
        pad(nt, 10, 4)
        nt.maxLines = 2
        nt.ellipsize = TextUtils.TruncateAt.END
        views[5] = nt

        for (i in 0 until Elems.COUNT) {
            val view = views[i] ?: continue
            canvasBox.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            view.measure(
                View.MeasureSpec.makeMeasureSpec(wPx, View.MeasureSpec.AT_MOST),
                View.MeasureSpec.makeMeasureSpec(hPx, View.MeasureSpec.AT_MOST)
            )
            tw[i] = view.measuredWidth
            th[i] = view.measuredHeight
            val p = Store.textPos(context, i)
            tx[i] = p.first
            ty[i] = p.second
            textViews[i] = view
            placeText(i)
        }
    }

    private fun placeText(i: Int) {
        val v = textViews[i] ?: return
        v.translationX = tx[i] * wPx
        v.translationY = ty[i] * hPx
    }

    private fun placeOverlay(slot: Int) {
        val v = ovViews[slot] ?: return
        v.translationX = ovCx[slot] * wPx - ovW[slot] / 2f
        v.translationY = ovCy[slot] * hPx - ovH[slot] / 2f
    }

    private fun rectOf(isText: Boolean, id: Int): RectF? {
        if (id < 0) return null
        if (isText) {
            if (id >= Elems.COUNT || textViews[id] == null) return null
            val l = tx[id] * wPx
            val t = ty[id] * hPx
            return RectF(l, t, l + tw[id], t + th[id])
        }
        if (id >= Store.OVERLAY_SLOTS || ovViews[id] == null) return null
        val l = ovCx[id] * wPx - ovW[id] / 2f
        val t = ovCy[id] * hPx - ovH[id] / 2f
        return RectF(l, t, l + ovW[id], t + ovH[id])
    }

    // ───────────────────────── выбор и рамка ─────────────────────────

    fun select(isText: Boolean, id: Int, notify: Boolean) {
        selIsText = isText
        selId = id
        updateFrame()
        if (notify) listener?.onSelect(isText, id)
    }

    private fun updateFrame() {
        val interactive = (dragMode == 1 && selIsText) || (dragMode == 2 && !selIsText)
        val r = if (interactive) rectOf(selIsText, selId) else null
        if (r == null) {
            frame.visibility = View.GONE
            return
        }
        val pd = 3f * dens
        frame.layoutParams = FrameLayout.LayoutParams((r.width() + 2 * pd).toInt(), (r.height() + 2 * pd).toInt())
        frame.translationX = r.left - pd
        frame.translationY = r.top - pd
        frame.visibility = View.VISIBLE
        frame.bringToFront()
    }

    /** Задаёт положение снаружи (синхронизация с другим превью или сброс). Ничего не сохраняет. */
    fun setPos(isText: Boolean, id: Int, x: Float, y: Float) {
        if (isText) {
            if (id < 0 || id >= Elems.COUNT) return
            tx[id] = x
            ty[id] = y
            placeText(id)
        } else {
            if (id < 0 || id >= Store.OVERLAY_SLOTS) return
            ovCx[id] = x
            ovCy[id] = y
            placeOverlay(id)
        }
        if (isText == selIsText && id == selId) updateFrame()
    }

    // ───────────────────────── движение ─────────────────────────

    /** Сдвиг выбранного элемента в пикселях виджета. */
    private fun moveSel(dx: Float, dy: Float) {
        val id = selId
        if (id < 0) return
        if (selIsText) {
            if (id >= Elems.COUNT || textViews[id] == null) return
            val maxX = maxOf(0f, 1f - tw[id] / wPx.toFloat())
            val maxY = maxOf(0f, 1f - th[id] / hPx.toFloat())
            tx[id] = (tx[id] + dx / wPx).coerceIn(0f, maxX)
            ty[id] = (ty[id] + dy / hPx).coerceIn(0f, maxY)
            placeText(id)
            listener?.onMove(true, id, tx[id], ty[id])
        } else {
            if (id >= Store.OVERLAY_SLOTS || ovViews[id] == null) return
            val ex = ovW[id] / wPx.toFloat()
            val ey = ovH[id] / hPx.toFloat()
            ovCx[id] = Overlays.clampCenter(ovCx[id] + dx / wPx, ex)
            ovCy[id] = Overlays.clampCenter(ovCy[id] + dy / hPx, ey)
            placeOverlay(id)
            listener?.onMove(false, id, ovCx[id], ovCy[id])
        }
        updateFrame()
    }

    private fun commitSel() {
        val id = selId
        if (id < 0) return
        if (selIsText) {
            if (id < Elems.COUNT && textViews[id] != null) listener?.onCommit(true, id, tx[id], ty[id])
        } else {
            if (id < Store.OVERLAY_SLOTS && ovViews[id] != null) listener?.onCommit(false, id, ovCx[id], ovCy[id])
        }
    }

    /** Сдвиг кнопками-стрелками, в dp. */
    fun nudge(dxDp: Float, dyDp: Float) {
        moveSel(dxDp * dens, dyDp * dens)
        commitSel()
    }

    // ───────────────────────── касания ─────────────────────────

    private fun hitTest(x: Float, y: Float): Int {
        val pd = 10f * dens / scaleF
        fun inside(r: RectF?): Boolean =
            r != null && x >= r.left - pd && x <= r.right + pd && y >= r.top - pd && y <= r.bottom + pd

        val isText = dragMode == 1
        // сначала проверяем уже выбранный элемент, чтобы можно было тянуть его поверх соседей
        if (selId >= 0 && selIsText == isText && inside(rectOf(isText, selId))) return selId
        val count = if (isText) Elems.COUNT else Store.OVERLAY_SLOTS
        for (i in count - 1 downTo 0) {
            if (inside(rectOf(isText, i))) return i
        }
        return -1
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean = dragMode != 0

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (dragMode == 0) return false
        val x = e.x / scaleF
        val y = e.y / scaleF
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val hit = hitTest(x, y)
                if (hit >= 0) {
                    select(dragMode == 1, hit, true)
                    dragging = true
                    lastX = x
                    lastY = y
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragging) {
                    moveSel(x - lastX, y - lastY)
                    lastX = x
                    lastY = y
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) {
                    dragging = false
                    commitSel()
                }
            }
        }
        return true
    }
}
