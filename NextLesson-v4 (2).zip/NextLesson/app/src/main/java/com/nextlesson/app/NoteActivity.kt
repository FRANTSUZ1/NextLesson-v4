package com.nextlesson.app

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout

/** Окно редактирования заметки. Открывается по нажатию на заметку в виджете. */
class NoteActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        NoteDialog.show(this) { finish() }
    }
}

object NoteDialog {
    fun show(a: Activity, onDone: () -> Unit) {
        val dp = a.resources.displayMetrics.density
        val pad = (20 * dp).toInt()

        val et = EditText(a)
        et.setText(Store.note(a))
        et.setSelection(et.text.length)
        et.hint = "Например: взять тетрадь, форму, линейку…"
        et.minLines = 3
        et.maxLines = 6
        et.gravity = Gravity.TOP or Gravity.START
        et.inputType = InputType.TYPE_CLASS_TEXT or
            InputType.TYPE_TEXT_FLAG_MULTI_LINE or
            InputType.TYPE_TEXT_FLAG_CAP_SENTENCES

        val box = FrameLayout(a)
        box.setPadding(pad, pad / 2, pad, 0)
        box.addView(et)

        val dlg = AlertDialog.Builder(a, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Заметка на виджете")
            .setView(box)
            .setPositiveButton("Сохранить") { _, _ ->
                Store.setNote(a, et.text.toString())
                WidgetUpdater.updateAll(a)
            }
            .setNeutralButton("Очистить") { _, _ ->
                Store.setNote(a, "")
                WidgetUpdater.updateAll(a)
            }
            .setNegativeButton("Отмена", null)
            .create()
        dlg.setOnDismissListener { onDone() }
        dlg.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        dlg.show()
    }
}
