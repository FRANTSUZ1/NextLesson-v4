package com.nextlesson.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews

class NextLessonWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        WidgetUpdater.updateAll(context)
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: Bundle?
    ) {
        super.onAppWidgetOptionsChanged(context, appWidgetManager, appWidgetId, newOptions)
        WidgetUpdater.updateAll(context)
    }

    override fun onEnabled(context: Context) {
        WidgetUpdater.updateAll(context)
    }

    override fun onDisabled(context: Context) {
        WidgetUpdater.cancelAlarm(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            WidgetUpdater.ACTION_REFRESH,
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_MY_PACKAGE_REPLACED -> WidgetUpdater.updateAll(context)
        }
    }
}

object WidgetUpdater {
    const val ACTION_REFRESH = "com.nextlesson.app.REFRESH"

    fun updateAll(c: Context) {
        val ctx = c.applicationContext
        val mgr = AppWidgetManager.getInstance(ctx)
        val ids = mgr.getAppWidgetIds(ComponentName(ctx, NextLessonWidget::class.java))
        if (ids.isEmpty()) {
            cancelAlarm(ctx)
            return
        }
        val st = Logic.compute(ctx)
        for (id in ids) {
            try {
                mgr.updateAppWidget(id, buildViews(ctx, mgr, id, st, true))
            } catch (e: Exception) {
                // например, картинки слишком тяжёлые для виджета — показываем без них
                try {
                    mgr.updateAppWidget(id, buildViews(ctx, mgr, id, st, false))
                } catch (e2: Exception) {
                }
            }
        }
        scheduleNext(ctx, st)
    }

    private fun refreshIntent(ctx: Context): PendingIntent {
        val i = Intent(ctx, NextLessonWidget::class.java).setAction(ACTION_REFRESH)
        return PendingIntent.getBroadcast(ctx, 1, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    fun cancelAlarm(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(refreshIntent(ctx))
    }

    private fun scheduleNext(ctx: Context, st: Logic.State) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = refreshIntent(ctx)
        am.cancel(pi)
        var target = st.refreshMs
        if (Store.noteExpires(ctx) && Store.note(ctx).isNotBlank()) {
            val mid = java.time.LocalDate.now(Store.zone(ctx)).plusDays(1)
                .atStartOfDay(Store.zone(ctx)).toInstant().toEpochMilli()
            target = minOf(target, mid)
        }
        val at = maxOf(target + 1000L, System.currentTimeMillis() + 1000L)
        val exactOk = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
        try {
            if (exactOk) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    /** Размер виджета на рабочем столе в dp (для редактора). Если виджета нет — обычный размер 4x3. */
    fun widgetSizeDp(c: Context): Pair<Int, Int> {
        val mgr = AppWidgetManager.getInstance(c)
        val ids = mgr.getAppWidgetIds(ComponentName(c, NextLessonWidget::class.java))
        if (ids.isEmpty()) return Pair(320, 200)
        return sizeDp(mgr, ids[0])
    }

    /** Размер виджета на экране в dp: (ширина, высота). */
    private fun sizeDp(mgr: AppWidgetManager, id: Int): Pair<Int, Int> {
        val o = mgr.getAppWidgetOptions(id)
        var wDp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
        var hDp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
        if (wDp <= 0) wDp = 250
        if (hDp <= 0) hDp = 150
        return Pair(wDp, hDp)
    }

    /** Градиентный фон нужного размера (с учётом размера виджета на экране). */
    private fun background(ctx: Context, wDp: Int, hDp: Int, g: Grad): android.graphics.Bitmap {
        val d = ctx.resources.displayMetrics.density
        var w = wDp * d
        var h = hDp * d
        val k = minOf(1f, 720f / maxOf(w, h))
        w *= k
        h *= k
        return Themes.bitmap(w.toInt(), h.toInt(), g, 22f * d * k)
    }

    /** Кладёт картинки/гифки в слои виджета. Каждая стоит там, куда её поставили пальцем. */
    private fun applyOverlays(ctx: Context, v: RemoteViews, wDp: Int, hDp: Int, enabled: Boolean) {
        val ids = intArrayOf(
            R.id.w_ov0, R.id.w_ov1, R.id.w_ov2, R.id.w_ov3, R.id.w_ov4,
            R.id.w_ov5, R.id.w_ov6, R.id.w_ov7, R.id.w_ov8, R.id.w_ov9
        )
        val d = ctx.resources.displayMetrics.density
        val wPx = (wDp * d).toInt()
        val hPx = (hDp * d).toInt()

        val active = ArrayList<Store.Overlay>()
        if (enabled) {
            for (slot in 0 until Store.OVERLAY_SLOTS) {
                val o = Store.overlay(ctx, slot)
                if (o != null) active.add(o)
            }
        }
        // общий запас памяти на все картинки делим поровну
        val budget = (5 * 1024 * 1024 / maxOf(1, active.size)).coerceAtLeast(200 * 1024)

        for (slot in 0 until Store.OVERLAY_SLOTS) {
            val layer = ids[slot]
            v.removeAllViews(layer)
            val ov = active.firstOrNull { it.slot == slot }
            val pl = if (ov != null) Overlays.place(ctx, ov, wPx, hPx, budget) else null
            if (pl == null) {
                v.setViewVisibility(layer, View.GONE)
                continue
            }
            for (b in pl.bitmaps) {
                val f = RemoteViews(ctx.packageName, R.layout.widget_frame)
                f.setImageViewBitmap(R.id.w_frame, b)
                v.addView(layer, f)
            }
            v.setViewPadding(layer, pl.padX, pl.padY, 0, 0)
            v.setInt(layer, "setFlipInterval", pl.intervalMs)
            v.setViewVisibility(layer, View.VISIBLE)
        }
    }

    private fun buildViews(ctx: Context, mgr: AppWidgetManager, id: Int, st: Logic.State, withOverlays: Boolean): RemoteViews {
        val g = Store.grad(ctx)
        val tc = Themes.textColor(g)
        val sec = Themes.withAlpha(tc, 0xCC)
        val pill = if (Themes.isLight(g)) R.drawable.pill_dark else R.drawable.pill_light
        val (wDp, hDp) = sizeDp(mgr, id)
        val dens = ctx.resources.displayMetrics.density
        val wPx = (wDp * dens).toInt()
        val hPx = (hDp * dens).toInt()

        val v = RemoteViews(ctx.packageName, R.layout.widget_next_lesson)

        // положение каждого текста: отступ слева и сверху внутри виджета
        fun place(wrapper: Int, elem: Int) {
            val pos = Store.textPos(ctx, elem)
            val x = (pos.first * wPx).toInt().coerceIn(0, maxOf(0, wPx - (24 * dens).toInt()))
            val y = (pos.second * hPx).toInt().coerceIn(0, maxOf(0, hPx - (16 * dens).toInt()))
            v.setViewPadding(wrapper, x, y, 0, 0)
        }
        place(R.id.w_p_header, 0)
        place(R.id.w_p_timer, 1)
        place(R.id.w_p_when, 2)
        place(R.id.w_p_subject, 3)
        place(R.id.w_p_place, 4)
        place(R.id.w_p_note, 5)

        v.setImageViewBitmap(R.id.w_bg, background(ctx, wDp, hDp, g))
        applyOverlays(ctx, v, wDp, hDp, withOverlays)

        v.setTextViewText(R.id.w_header, Logic.header(ctx, st))
        v.setTextColor(R.id.w_header, sec)
        v.setInt(R.id.w_timer_pill, "setBackgroundResource", pill)
        v.setInt(R.id.w_flip, "setBackgroundResource", pill)
        v.setInt(R.id.w_solo, "setBackgroundResource", pill)
        v.setInt(R.id.w_note, "setBackgroundResource", pill)
        v.setTextColor(R.id.w_timer_label, sec)
        v.setTextColor(R.id.w_timer, tc)
        v.setTextColor(R.id.w_when, sec)
        v.setTextColor(R.id.w_subject, tc)
        v.setTextColor(R.id.w_fl_place, tc)
        v.setTextColor(R.id.w_fl_ord1, tc)
        v.setTextColor(R.id.w_fl_ord2, tc)
        v.setTextColor(R.id.w_solo, tc)
        v.setTextColor(R.id.w_note, tc)

        if (st.kind == Logic.Kind.NONE || st.lesson == null) {
            v.setViewVisibility(R.id.w_timer_pill, View.GONE)
            v.setViewVisibility(R.id.w_when, View.GONE)
            v.setViewVisibility(R.id.w_flip, View.GONE)
            v.setViewVisibility(R.id.w_solo, View.GONE)
            v.setTextViewText(R.id.w_subject, "Добавь " + Vocabs.cur(ctx).nomPl + " в приложении")
        } else {
            val l = st.lesson
            v.setViewVisibility(R.id.w_timer_pill, View.VISIBLE)
            v.setViewVisibility(R.id.w_when, View.VISIBLE)
            v.setTextViewText(R.id.w_timer_label, Logic.countdownLabel(ctx, st))
            v.setTextViewText(R.id.w_when, Logic.whenText(st))
            v.setTextViewText(R.id.w_subject, l.name)

            // кабинет и «какой по счёту урок» — одна плашка: 5 сек кабинет, 10 сек номер урока
            val ord = Logic.ordinal(ctx, st)
            if (l.place.isBlank()) {
                v.setViewVisibility(R.id.w_flip, View.GONE)
                v.setViewVisibility(R.id.w_solo, View.VISIBLE)
                v.setTextViewText(R.id.w_solo, ord)
            } else {
                v.setViewVisibility(R.id.w_solo, View.GONE)
                v.setViewVisibility(R.id.w_flip, View.VISIBLE)
                v.setTextViewText(R.id.w_fl_place, l.place)
                v.setTextViewText(R.id.w_fl_ord1, ord)
                v.setTextViewText(R.id.w_fl_ord2, ord)
            }
            val base = SystemClock.elapsedRealtime() + (st.targetMs - System.currentTimeMillis())
            v.setChronometerCountDown(R.id.w_timer, true)
            v.setChronometer(R.id.w_timer, base, null, true)
        }

        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        // Заметка: если она не записана — плашки нет. Записать можно только в приложении.
        val note = Store.note(ctx)
        if (note.isBlank()) {
            v.setViewVisibility(R.id.w_note, View.GONE)
        } else {
            v.setViewVisibility(R.id.w_note, View.VISIBLE)
            v.setTextViewText(R.id.w_note, "📝  $note")
            if (Store.noteFromWidget(ctx)) {
                val noteIntent = PendingIntent.getActivity(
                    ctx, 2,
                    Intent(ctx, NoteActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                v.setOnClickPendingIntent(R.id.w_note, noteIntent)
            } else {
                v.setOnClickPendingIntent(R.id.w_note, open)
            }
        }

        v.setOnClickPendingIntent(R.id.w_root, open)
        return v
    }
}
