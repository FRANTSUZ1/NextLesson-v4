package com.nextlesson.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Movie
import java.io.File

/** Готовит картинки и гифки для виджета. Виджет не умеет проигрывать GIF, поэтому гиф режется на кадры. */
object Overlays {

    /** Кадры целиком (без обрезки по краям виджета). */
    class Frames(
        val bitmaps: List<Bitmap>,
        val intervalMs: Int,
        val dispW: Int,
        val dispH: Int,
        val fw: Int,
        val fh: Int
    )

    /** Кадры, уже обрезанные по границам виджета, и отступ от левого верхнего угла. */
    class Placed(val bitmaps: List<Bitmap>, val intervalMs: Int, val padX: Int, val padY: Int)

    private val cache = HashMap<String, Frames>()
    private val thumbs = HashMap<String, Bitmap>()

    fun isGif(b: ByteArray): Boolean =
        b.size > 6 && b[0] == 'G'.code.toByte() && b[1] == 'I'.code.toByte() && b[2] == 'F'.code.toByte()

    /** Ширина / высота файла. */
    fun aspect(f: File): Float {
        return try {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            BitmapFactory.decodeFile(f.path, o)
            if (o.outWidth > 0 && o.outHeight > 0) o.outWidth.toFloat() / o.outHeight else 1f
        } catch (e: Exception) {
            1f
        }
    }

    /** Размер картинки на виджете в пикселях (ширина, высота). */
    fun dispSize(ov: Store.Overlay, wPx: Int, hPx: Int): Pair<Int, Int> {
        val ar = if (ov.ar > 0.01f) ov.ar else 1f
        var dh = (hPx * ov.size / 100f).toInt().coerceAtLeast(16)
        var dw = (dh * ar).toInt().coerceAtLeast(16)
        val maxW = (wPx * 0.95f).toInt()
        if (dw > maxW) {
            dw = maxW
            dh = (dw / ar).toInt().coerceAtLeast(16)
        }
        return Pair(dw, dh)
    }

    /**
     * Ограничивает центр картинки: она может выходить за край виджета,
     * но не больше чем на треть своего размера. extent — размер картинки в долях виджета по этой оси.
     */
    fun clampCenter(v: Float, extent: Float): Float {
        val lo = 0.15f * extent
        return v.coerceIn(lo, 1f - lo)
    }

    private fun frames(ctx: Context, ov: Store.Overlay, wPx: Int, hPx: Int, budget: Int): Frames? {
        val size = dispSize(ov, wPx, hPx)
        val dw = size.first
        val dh = size.second
        val key = "${ov.slot}-${ov.ts}-${ov.gif}-${dw}x$dh-$budget"
        cache[key]?.let { return it }

        val bytes: ByteArray = try {
            Store.overlayFile(ctx, ov.slot).readBytes()
        } catch (e: Exception) {
            return null
        }

        var movie: Movie? = null
        if (ov.gif && isGif(bytes)) {
            movie = try {
                Movie.decodeByteArray(bytes, 0, bytes.size)
            } catch (e: Throwable) {
                null
            }
        }
        var iw: Int
        var ih: Int
        if (movie != null && movie.width() > 0 && movie.height() > 0) {
            iw = movie.width()
            ih = movie.height()
        } else {
            movie = null
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
            iw = o.outWidth
            ih = o.outHeight
        }
        if (iw <= 0 || ih <= 0) return null

        val mv = movie
        val dur = mv?.duration() ?: 0
        val n = if (mv != null && dur > 0) (dur / 100).coerceIn(2, 10) else 1

        // размер кадра: не больше предела и не больше доли общего бюджета памяти
        val cap = if (mv != null) 200f else 480f
        var k = minOf(1f, cap / maxOf(dw, dh))
        val maxPx = budget / 4f / n
        val cur = (dw * k) * (dh * k)
        if (cur > maxPx) k *= Math.sqrt((maxPx / cur).toDouble()).toFloat()
        val fw = (dw * k).toInt().coerceAtLeast(8)
        val fh = (dh * k).toInt().coerceAtLeast(8)
        val dpi = ctx.resources.displayMetrics.densityDpi
        // плотность подбираем так, чтобы на экране кадр занимал ровно dw x dh пикселей
        val density = (dpi * fw / dw.toFloat()).toInt().coerceAtLeast(1)

        val out = ArrayList<Bitmap>()
        var interval = 1000

        if (mv != null && dur > 0) {
            interval = maxOf(100, dur / n)
            for (i in 0 until n) {
                val b = Bitmap.createBitmap(fw, fh, Bitmap.Config.ARGB_8888)
                val c = Canvas(b)
                c.scale(fw.toFloat() / iw, fh.toFloat() / ih)
                mv.setTime(i * dur / n)
                mv.draw(c, 0f, 0f)
                b.density = density
                out.add(b)
            }
        }
        if (out.isEmpty()) {
            val o = BitmapFactory.Options()
            var sample = 1
            while (iw / (sample * 2) >= fw && ih / (sample * 2) >= fh) sample *= 2
            o.inSampleSize = sample
            val src = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o) ?: return null
            val scaled = if (src.width == fw && src.height == fh) src
            else Bitmap.createScaledBitmap(src, fw, fh, true)
            scaled.density = density
            out.add(scaled)
        }

        val f = Frames(out, interval, dw, dh, fw, fh)
        if (cache.size > 14) cache.clear()
        cache[key] = f
        return f
    }

    /**
     * Кадры для виджета: картинка стоит там, куда её поставили пальцем.
     * Часть, которая выходит за границы виджета, обрезается.
     * budget — сколько байт памяти можно потратить на эту картинку.
     */
    fun place(ctx: Context, ov: Store.Overlay, wPx: Int, hPx: Int, budget: Int): Placed? {
        val fr = frames(ctx, ov, wPx, hPx, budget) ?: return null
        val dw = fr.dispW
        val dh = fr.dispH
        val left = ov.cx * wPx - dw / 2f
        val top = ov.cy * hPx - dh / 2f
        val vx0 = maxOf(0f, left)
        val vy0 = maxOf(0f, top)
        val vx1 = minOf(wPx.toFloat(), left + dw)
        val vy1 = minOf(hPx.toFloat(), top + dh)
        if (vx1 - vx0 < 2f || vy1 - vy0 < 2f) return null

        val kx = fr.fw / dw.toFloat()
        val ky = fr.fh / dh.toFloat()
        val sx = ((vx0 - left) * kx).toInt().coerceIn(0, fr.fw - 1)
        val sy = ((vy0 - top) * ky).toInt().coerceIn(0, fr.fh - 1)
        val sw = ((vx1 - vx0) * kx).toInt().coerceIn(1, fr.fw - sx)
        val sh = ((vy1 - vy0) * ky).toInt().coerceIn(1, fr.fh - sy)
        val whole = sx == 0 && sy == 0 && sw == fr.fw && sh == fr.fh

        val dpi = ctx.resources.displayMetrics.densityDpi
        val density = (dpi * fr.fw / dw.toFloat()).toInt().coerceAtLeast(1)
        val out = ArrayList<Bitmap>()
        for (b in fr.bitmaps) {
            val c = if (whole) b else Bitmap.createBitmap(b, sx, sy, sw, sh)
            c.density = density
            out.add(c)
        }
        return Placed(out, fr.intervalMs, vx0.toInt(), vy0.toInt())
    }

    /** Одна картинка (первый кадр) для превью в приложении. */
    fun thumb(ctx: Context, slot: Int, ts: Long, maxPx: Int): Bitmap? {
        val key = "$slot-$ts-$maxPx"
        thumbs[key]?.let { return it }
        val bytes: ByteArray = try {
            Store.overlayFile(ctx, slot).readBytes()
        } catch (e: Exception) {
            return null
        }
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        if (o.outWidth <= 0 || o.outHeight <= 0) return null
        var sample = 1
        while (o.outWidth / (sample * 2) >= maxPx || o.outHeight / (sample * 2) >= maxPx) sample *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = sample
        val b = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2) ?: return null
        if (thumbs.size > 24) thumbs.clear()
        thumbs[key] = b
        return b
    }
}
