package com.nextlesson.app

import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.appwidget.AppWidgetManager
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.Switch
import android.widget.SeekBar
import android.widget.TextView
import android.widget.TimePicker
import android.widget.Toast
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.util.Locale

class MainActivity : Activity() {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val handler = Handler(Looper.getMainLooper())

    /** 0 = расписание по датам, 1 = шаблон недели. */
    private var mode = 0
    private var selDay = 1
    private var selDate: LocalDate = LocalDate.now()
    private var calMonth: YearMonth = YearMonth.now()
    private var grad: Grad = Themes.DEFAULT
    private var uiG: Grad = C.DEFAULT_UI
    private var pillShown = ""

    private lateinit var pHeader: TextView
    private lateinit var pTimer: TextView
    private lateinit var pWhen: TextView
    private lateinit var pSubject: TextView
    private lateinit var pPill: TextView
    private lateinit var pNote: TextView
    private lateinit var tzBtn: TextView
    private lateinit var alarmBtn: TextView
    private lateinit var modeRow: LinearLayout
    private lateinit var tabs: LinearLayout
    private lateinit var dayTitle: TextView
    private lateinit var dayBadge: TextView
    private lateinit var dayList: LinearLayout
    private lateinit var calTitle: TextView
    private lateinit var calGrid: LinearLayout
    private lateinit var calInfo: TextView
    private lateinit var noteText: TextView
    private lateinit var drawer: LinearLayout
    private lateinit var scrim: View
    private var drawerOpen = false
    private val drawerW by lazy { dp(290) }

    private val MONTHS = arrayOf(
        "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
        "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"
    )

    private val tick = object : Runnable {
        override fun run() {
            updatePreview()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        selDate = LocalDate.now(Store.zone(this))
        selDay = selDate.dayOfWeek.value
        calMonth = YearMonth.from(selDate)
        build()
    }

    override fun onResume() {
        super.onResume()
        refreshButtons()
        WidgetUpdater.updateAll(this)
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (drawerOpen) closeDrawer() else super.onBackPressed()
    }

    // ───────────────────────── helpers ─────────────────────────

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun today(): LocalDate = LocalDate.now(Store.zone(this))

    private fun rounded(fill: Int, radiusDp: Int, stroke: Int = 0, strokeDp: Int = 1): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(fill)
        d.cornerRadius = dp(radiusDp).toFloat()
        if (stroke != 0) d.setStroke(dp(strokeDp), stroke)
        return d
    }

    /** Цвета кнопок/выделений в приложении, зависящие от выбранного градиента. */
    private fun ui(): Grad = Grad(Themes.lift(uiG.c1), Themes.lift(uiG.c2), 0)

    private fun gradient(radiusDp: Int): GradientDrawable {
        val u = ui()
        val d = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(u.c1, u.c2))
        d.cornerRadius = dp(radiusDp).toFloat()
        return d
    }

    /** Цвет текста на «главной» кнопке. */
    private fun onPrimary(): Int = Themes.textColor(ui())

    private fun text(s: String, sizeSp: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = sizeSp
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    private fun lp(top: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(MATCH, WRAP)
        p.topMargin = dp(top)
        return p
    }

    private fun btn(label: String, primary: Boolean, onClick: () -> Unit): TextView {
        val t = text(label, 16f, if (primary) onPrimary() else C.ACCENT, true)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(16), dp(16), dp(16), dp(16))
        t.background = if (primary) gradient(22) else rounded(C.CARD2, 22, C.STROKE)
        t.setOnClickListener { onClick() }
        return t
    }

    private fun card(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.background = rounded(C.CARD, 24, C.STROKE)
        l.setPadding(dp(18), dp(16), dp(18), dp(18))
        return l
    }

    private fun darkDialog() = AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)

    // ───────────────────────── построение экрана ─────────────────────────

    private fun build() {
        grad = Store.grad(this)
        uiG = Store.uiGrad(this)
        C.apply(uiG)
        pillShown = ""
        window.statusBarColor = C.BG1
        window.navigationBarColor = C.BG1

        val frame = FrameLayout(this)
        frame.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(C.BG1, C.BG2, C.BG1)
        )
        frame.addView(buildContent(), FrameLayout.LayoutParams(MATCH, MATCH))

        scrim = View(this)
        scrim.setBackgroundColor(Color.argb(150, 0, 0, 0))
        scrim.visibility = View.GONE
        scrim.setOnClickListener { closeDrawer() }
        frame.addView(scrim, FrameLayout.LayoutParams(MATCH, MATCH))

        drawer = buildDrawer()
        drawer.translationX = -drawerW.toFloat()
        frame.addView(drawer, FrameLayout.LayoutParams(drawerW, MATCH))

        drawerOpen = false
        setContentView(frame)

        renderModeRow()
        renderTabs()
        renderDay()
        renderCalendar()
        renderNote()
        refreshButtons()
        updatePreview()
    }

    private fun buildContent(): View {
        val scroll = ScrollView(this)
        scroll.isFillViewport = true

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(18), dp(40), dp(18), dp(36))
        scroll.addView(root)

        // верхняя строка: кнопка меню + заголовок
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val menuBtn = text("☰", 24f, Color.WHITE, true)
        menuBtn.gravity = Gravity.CENTER
        menuBtn.background = rounded(C.CARD2, 16, C.STROKE)
        menuBtn.setOnClickListener { openDrawer() }
        top.addView(menuBtn, LinearLayout.LayoutParams(dp(48), dp(48)))
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.setPadding(dp(14), 0, 0, 0)
        titles.addView(text(Vocabs.nextTitle(Vocabs.cur(this)), 26f, Color.WHITE, true))
        titles.addView(text("Что дальше, где и через сколько", 13f, C.MUTED))
        top.addView(titles, LinearLayout.LayoutParams(0, WRAP, 1f))
        root.addView(top, lp(0))

        // Превью (как виджет)
        val prev = LinearLayout(this)
        prev.orientation = LinearLayout.VERTICAL
        prev.background = Themes.drawable(grad, dp(26).toFloat(), dp(1), Color.argb(60, 255, 255, 255))
        prev.setPadding(dp(18), dp(16), dp(18), dp(18))
        pHeader = text("", 12f, Color.WHITE, true)
        pTimer = text("", 14f, Color.WHITE, true)
        pWhen = text("", 12f, Color.WHITE)
        pSubject = text("", 28f, Color.WHITE, true)
        pPill = text("", 14f, Color.WHITE)
        pPill.gravity = Gravity.CENTER
        pPill.setPadding(dp(14), dp(5), dp(14), dp(5))
        pNote = text("", 13f, Color.WHITE)
        pNote.setPadding(dp(12), dp(7), dp(12), dp(7))
        pNote.setOnClickListener { editNote() }
        prev.addView(pHeader)
        prev.addView(pTimer, lp(6))
        prev.addView(pWhen, lp(8))
        prev.addView(pSubject, lp(2))
        val wrapLp = LinearLayout.LayoutParams(WRAP, WRAP)
        wrapLp.topMargin = dp(8)
        prev.addView(pPill, wrapLp)
        prev.addView(pNote, lp(8))
        root.addView(prev, lp(18))

        // Заметка
        val noteCard = card()
        noteCard.addView(text("Заметка на виджете", 18f, Color.WHITE, true))
        noteText = text("", 15f, C.MUTED)
        noteCard.addView(noteText, lp(6))
        noteCard.addView(
            text("Если заметка записана, она появляется на виджете. Пока её нет — плашки на виджете тоже нет.", 12f, C.MUTED),
            lp(6)
        )
        noteCard.addView(btn("✎  Написать / изменить заметку", false) { editNote() }, lp(10))

        val swExpire = Switch(this)
        swExpire.text = "Удалять заметку на следующий день"
        swExpire.setTextColor(Color.WHITE)
        swExpire.isChecked = Store.noteExpires(this)
        swExpire.setOnCheckedChangeListener { _, on ->
            Store.setNoteExpires(this, on)
            WidgetUpdater.updateAll(this)
        }
        noteCard.addView(swExpire, lp(14))

        val swWidget = Switch(this)
        swWidget.text = "Менять заметку с виджета"
        swWidget.setTextColor(Color.WHITE)
        swWidget.isChecked = Store.noteFromWidget(this)
        swWidget.setOnCheckedChangeListener { _, on ->
            Store.setNoteFromWidget(this, on)
            WidgetUpdater.updateAll(this)
        }
        noteCard.addView(swWidget, lp(10))
        noteCard.addView(
            text("Выключено — на виджете заметку не изменить, только в приложении.", 12f, C.MUTED),
            lp(2)
        )
        root.addView(noteCard, lp(16))

        // Расписание
        val sched = card()
        modeRow = LinearLayout(this)
        modeRow.orientation = LinearLayout.HORIZONTAL
        sched.addView(modeRow)

        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        hs.addView(tabs)
        sched.addView(hs, lp(12))

        dayTitle = text("", 22f, Color.WHITE, true)
        sched.addView(dayTitle, lp(14))
        dayBadge = text("", 13f, C.MUTED)
        sched.addView(dayBadge, lp(2))
        dayList = LinearLayout(this)
        dayList.orientation = LinearLayout.VERTICAL
        sched.addView(dayList, lp(8))
        root.addView(sched, lp(16))

        // Календарь пропусков
        val cal = card()
        cal.addView(text("Календарь пропусков", 18f, Color.WHITE, true))
        val nav = LinearLayout(this)
        nav.orientation = LinearLayout.HORIZONTAL
        nav.gravity = Gravity.CENTER_VERTICAL
        val prevM = text("‹", 26f, C.ACCENT, true)
        prevM.gravity = Gravity.CENTER
        prevM.background = rounded(C.CARD2, 14, C.STROKE)
        prevM.setOnClickListener {
            calMonth = calMonth.minusMonths(1)
            renderCalendar()
        }
        val nextM = text("›", 26f, C.ACCENT, true)
        nextM.gravity = Gravity.CENTER
        nextM.background = rounded(C.CARD2, 14, C.STROKE)
        nextM.setOnClickListener {
            calMonth = calMonth.plusMonths(1)
            renderCalendar()
        }
        calTitle = text("", 17f, Color.WHITE, true)
        calTitle.gravity = Gravity.CENTER
        nav.addView(prevM, LinearLayout.LayoutParams(dp(44), dp(40)))
        nav.addView(calTitle, LinearLayout.LayoutParams(0, WRAP, 1f))
        nav.addView(nextM, LinearLayout.LayoutParams(dp(44), dp(40)))
        cal.addView(nav, lp(12))
        calGrid = LinearLayout(this)
        calGrid.orientation = LinearLayout.VERTICAL
        cal.addView(calGrid, lp(8))
        calInfo = text("", 13f, C.MUTED)
        cal.addView(calInfo, lp(10))
        cal.addView(text("Нажми на день, чтобы отметить пропуск. Нажми ещё раз — снять отметку.", 12f, C.MUTED), lp(4))
        root.addView(cal, lp(16))

        val foot = text("Все времена считаются по выбранному часовому поясу.", 12f, C.MUTED)
        foot.gravity = Gravity.CENTER
        root.addView(foot, lp(16))
        return scroll
    }

    // ───────────────────────── боковое меню ─────────────────────────

    private fun menuItem(label: String, onClick: () -> Unit): TextView {
        val t = text(label, 16f, Color.WHITE, true)
        t.setPadding(dp(16), dp(16), dp(16), dp(16))
        t.background = rounded(C.CARD2, 16, C.STROKE)
        t.setOnClickListener {
            closeDrawer()
            onClick()
        }
        return t
    }

    private fun section(label: String): TextView {
        val t = text(label.uppercase(Locale.ROOT), 12f, C.ACCENT, true)
        t.setPadding(dp(4), 0, 0, 0)
        return t
    }

    private fun buildDrawer(): LinearLayout {
        val d = LinearLayout(this)
        d.orientation = LinearLayout.VERTICAL
        d.background = rounded(C.CARD, 0, C.STROKE)
        d.isClickable = true  // чтобы нажатия не проваливались на экран под меню

        val inner = LinearLayout(this)
        inner.orientation = LinearLayout.VERTICAL
        inner.setPadding(dp(18), dp(52), dp(18), dp(24))
        val sv = ScrollView(this)
        sv.addView(inner)
        d.addView(sv, LinearLayout.LayoutParams(MATCH, MATCH))

        inner.addView(text("Меню", 24f, Color.WHITE, true))
        inner.addView(text("Настройки приложения и виджета", 13f, C.MUTED), lp(2))

        inner.addView(section("Профиль"), lp(20))
        inner.addView(menuItem("👤   Режим: " + Vocabs.cur(this).title) { showVocabDialog() }, lp(8))

        inner.addView(section("Кастомизация"), lp(20))
        inner.addView(menuItem("🎨   Цвета виджета") { showColorsDialog(true) }, lp(8))
        inner.addView(menuItem("🖌   Цвета приложения") { showColorsDialog(false) }, lp(8))
        inner.addView(menuItem("🖼   Картинки и гифки (до 10)") { openEditor(1) }, lp(8))
        inner.addView(menuItem("✥   Положение текста на виджете") { openEditor(0) }, lp(8))

        inner.addView(section("Приложение"), lp(20))
        tzBtn = menuItem("") { showTzDialog() }
        inner.addView(tzBtn, lp(8))
        alarmBtn = menuItem("") { askExactAlarms() }
        inner.addView(alarmBtn, lp(8))

        inner.addView(section("Виджет"), lp(20))
        inner.addView(menuItem("➕   Добавить виджет на экран") { pinWidget() }, lp(8))
        return d
    }

    private fun openDrawer() {
        if (drawerOpen) return
        drawerOpen = true
        scrim.visibility = View.VISIBLE
        scrim.alpha = 0f
        scrim.animate().alpha(1f).setDuration(200).start()
        drawer.animate().translationX(0f).setDuration(220).start()
    }

    private fun closeDrawer() {
        if (!drawerOpen) return
        drawerOpen = false
        scrim.animate().alpha(0f).setDuration(200).withEndAction {
            if (!drawerOpen) scrim.visibility = View.GONE
        }.start()
        drawer.animate().translationX(-drawerW.toFloat()).setDuration(220).start()
    }

    // ───────────────────────── расписание ─────────────────────────

    private fun currentList(): MutableList<Lesson> =
        if (mode == 0) Store.loadDate(this, selDate) else Store.loadDay(this, selDay)

    private fun renderModeRow() {
        modeRow.removeAllViews()
        val labels = listOf("По датам", "Шаблон недели")
        for (i in labels.indices) {
            val sel = mode == i
            val t = text(labels[i], 14f, if (sel) onPrimary() else C.MUTED, true)
            t.gravity = Gravity.CENTER
            t.setPadding(dp(8), dp(11), dp(8), dp(11))
            t.background = if (sel) gradient(16) else rounded(C.CARD2, 16, C.STROKE)
            t.setOnClickListener {
                mode = i
                renderModeRow()
                renderTabs()
                renderDay()
            }
            val p = LinearLayout.LayoutParams(0, WRAP, 1f)
            if (i == 0) p.rightMargin = dp(8)
            modeRow.addView(t, p)
        }
    }

    private fun renderTabs() {
        tabs.removeAllViews()
        if (mode == 1) {
            for (d in 1..7) {
                val sel = d == selDay
                val t = text(Logic.DAYS_SHORT[d - 1], 15f, if (sel) onPrimary() else C.MUTED, true)
                t.gravity = Gravity.CENTER
                t.setPadding(dp(18), dp(10), dp(18), dp(10))
                t.background = if (sel) gradient(18) else rounded(C.CARD2, 18, C.STROKE)
                t.setOnClickListener {
                    selDay = d
                    renderTabs()
                    renderDay()
                }
                val p = LinearLayout.LayoutParams(WRAP, WRAP)
                p.rightMargin = dp(8)
                tabs.addView(t, p)
            }
            return
        }

        // даты на месяц вперёд
        val start = today()
        val recorded = Store.recordedDates(this)
        val meet = Store.meetingDates(this)
        for (i in 0..30) {
            val d = start.plusDays(i.toLong())
            val sel = d == selDate
            val rec = recorded.contains(d.toString())

            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER_HORIZONTAL
            col.setPadding(dp(12), dp(8), dp(12), dp(6))

            val dow = text(
                Logic.DAYS_SHORT[d.dayOfWeek.value - 1], 14f,
                if (sel) onPrimary() else if (i == 0) C.ACCENT else C.MUTED, true
            )
            val dt = text(
                Logic.dm(d), 12f,
                if (sel) onPrimary() else if (rec) C.GREEN else C.MUTED
            )
            val mark = text(
                (if (rec) "✓" else " ") + (if (meet.contains(d.toString())) "📅" else ""), 11f,
                if (sel) onPrimary() else C.GREEN, true
            )
            dow.gravity = Gravity.CENTER
            dt.gravity = Gravity.CENTER
            mark.gravity = Gravity.CENTER
            col.addView(dow)
            col.addView(dt)
            col.addView(mark)

            col.background = if (sel) gradient(16)
            else rounded(C.CARD2, 16, if (rec) C.GREEN else C.STROKE, if (rec) 2 else 1)
            col.setOnClickListener {
                selDate = d
                renderTabs()
                renderDay()
            }
            val p = LinearLayout.LayoutParams(WRAP, WRAP)
            p.rightMargin = dp(8)
            tabs.addView(col, p)
        }
    }

    private fun renderDay() {
        dayList.removeAllViews()
        val list = currentList()
        val voc = Vocabs.cur(this)

        if (mode == 1) {
            dayTitle.text = Logic.DAYS_FULL[selDay - 1]
            dayBadge.text = "Шаблон: повторяется каждую неделю. На конкретную дату можно записать своё."
            dayBadge.setTextColor(C.MUTED)
        } else {
            val rec = Store.hasDate(this, selDate)
            dayTitle.text = Logic.DAYS_FULL[selDate.dayOfWeek.value - 1] + ", " + Logic.dm(selDate)
            if (rec) {
                dayBadge.text = "✓ День записан"
                dayBadge.setTextColor(C.GREEN)
            } else {
                dayBadge.text = "Пока по шаблону недели. Измени уроки или нажми «Записать день»."
                dayBadge.setTextColor(C.MUTED)
            }
        }

        if (list.isEmpty()) {
            dayList.addView(text("В этот день " + voc.genPl + " нет. Нажми «Добавить " + voc.accSg + "».", 15f, C.MUTED), lp(6))
        }

        var lessonNo = 0
        for ((i, l) in list.withIndex()) {
            if (l.kind == 0) lessonNo++
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.background = rounded(C.CARD2, 16, if (l.kind == 1) C.ACCENT else C.STROKE, if (l.kind == 1) 2 else 1)
            row.setPadding(dp(12), dp(10), dp(12), dp(10))

            val num = text(if (l.kind == 1) "📅" else "$lessonNo", 14f, C.ACCENT, true)
            num.gravity = Gravity.CENTER
            num.background = rounded(C.PILL, 10)
            num.setPadding(dp(11), dp(6), dp(11), dp(6))
            row.addView(num)

            val mid = LinearLayout(this)
            mid.orientation = LinearLayout.VERTICAL
            mid.setPadding(dp(12), 0, dp(8), 0)
            mid.addView(text(l.name, 17f, Color.WHITE, true))
            if (l.place.isNotBlank()) mid.addView(text(l.place, 13f, C.MUTED))
            row.addView(mid, LinearLayout.LayoutParams(0, WRAP, 1f))

            val times = text("${Logic.hm(l.start)}\n${Logic.hm(l.end)}", 14f, C.ACCENT, true)
            times.gravity = Gravity.END
            row.addView(times)

            row.setOnClickListener { showLessonDialog(l, i) }
            dayList.addView(row, lp(8))
        }

        dayList.addView(btn("+  Добавить " + voc.accSg, false) { showLessonDialog(null, -1, 0) }, lp(12))
        if (mode == 0 && voc.id != 3) {
            dayList.addView(btn("📅  Добавить встречу", false) { showLessonDialog(null, -1, 1) }, lp(8))
        }
        if (mode == 0) {
            if (!Store.hasDate(this, selDate)) {
                dayList.addView(btn("✓  Записать этот день", true) { persist(currentList()) }, lp(8))
            } else {
                dayList.addView(btn("Сбросить к шаблону недели", false) {
                    Store.clearDate(this, selDate)
                    WidgetUpdater.updateAll(this)
                    renderTabs()
                    renderDay()
                }, lp(8))
            }
        }
        if (list.isNotEmpty()) {
            dayList.addView(
                btn(if (mode == 0) "Скопировать на другие даты" else "Скопировать день на другие дни", false) {
                    if (mode == 0) showCopyDatesDialog() else showCopyDialog()
                }, lp(8)
            )
        }
    }

    /** Сохраняет список уроков для выбранного дня/даты. */
    private fun persist(list: List<Lesson>) {
        if (mode == 0) Store.saveDate(this, selDate, list) else Store.saveDay(this, selDay, list)
        WidgetUpdater.updateAll(this)
        renderTabs()
        renderDay()
    }

    // ───────────────────────── календарь пропусков ─────────────────────────

    private fun renderCalendar() {
        calGrid.removeAllViews()
        calTitle.text = MONTHS[calMonth.monthValue - 1] + " " + calMonth.year

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        for (d in Logic.DAYS_SHORT) {
            val t = text(d, 12f, C.MUTED, true)
            t.gravity = Gravity.CENTER
            head.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        calGrid.addView(head, lp(0))

        val missed = Store.missed(this)
        val today = today()
        val first = calMonth.atDay(1).dayOfWeek.value - 1
        val len = calMonth.lengthOfMonth()
        var day = 1 - first
        while (day <= len) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (k in 0 until 7) {
                val cell = TextView(this)
                cell.gravity = Gravity.CENTER
                val p = LinearLayout.LayoutParams(0, dp(42), 1f)
                p.setMargins(dp(2), dp(2), dp(2), dp(2))
                if (day in 1..len) {
                    val d = calMonth.atDay(day)
                    val isMissed = missed.contains(d.toString())
                    cell.text = day.toString()
                    cell.textSize = 14f
                    if (isMissed) {
                        cell.setTextColor(Color.parseColor("#2A0F18"))
                        cell.setTypeface(cell.typeface, Typeface.BOLD)
                        cell.background = rounded(C.DANGER, 12)
                    } else if (d == today) {
                        cell.setTextColor(C.ACCENT)
                        cell.setTypeface(cell.typeface, Typeface.BOLD)
                        cell.background = rounded(Color.TRANSPARENT, 12, C.ACCENT, 2)
                    } else {
                        cell.setTextColor(Color.WHITE)
                        cell.background = rounded(C.CARD2, 12)
                    }
                    cell.setOnClickListener {
                        Store.toggleMissed(this, d.toString())
                        renderCalendar()
                    }
                }
                row.addView(cell, p)
                day++
            }
            calGrid.addView(row, lp(0))
        }

        val ym = calMonth.toString()
        val n = missed.count { it.startsWith(ym) }
        calInfo.text = if (n == 0) "Пропусков в этом месяце нет" else "Пропущено дней в этом месяце: $n"
    }

    // ───────────────────────── заметка и превью ─────────────────────────

    private fun editNote() {
        NoteDialog.show(this) {
            renderNote()
            updatePreview()
        }
    }

    private fun renderNote() {
        val n = Store.note(this)
        if (n.isBlank()) {
            noteText.text = "Пока пусто. Например: «взять тетрадь по алгебре»."
            noteText.setTextColor(C.MUTED)
        } else {
            noteText.text = n
            noteText.setTextColor(Color.WHITE)
        }
    }

    private fun refreshButtons() {
        val id = Store.tzId(this)
        tzBtn.text = "🌐   Часовой пояс: " + if (id.isEmpty()) "как в системе (${ZoneId.systemDefault().id})" else id
        alarmBtn.text = "⏰   Точные обновления: " + if (canExact()) "включены" else "включить"
    }

    /** Плавно меняет текст плашки (кабинет ⇄ номер урока), как на виджете. */
    private fun setPill(t: String) {
        if (t == pillShown) return
        val first = pillShown.isEmpty()
        pillShown = t
        if (first) {
            pPill.text = t
            return
        }
        pPill.animate().alpha(0f).setDuration(300).withEndAction {
            pPill.text = pillShown
            pPill.animate().alpha(1f).setDuration(300).start()
        }.start()
    }

    private fun updatePreview() {
        val tc = Themes.textColor(grad)
        val sec = Themes.withAlpha(tc, 0xCC)
        val pillBg = if (Themes.isLight(grad)) Color.argb(34, 0, 0, 0) else Color.argb(51, 255, 255, 255)
        val pillStroke = if (Themes.isLight(grad)) Color.argb(68, 0, 0, 0) else Color.argb(85, 255, 255, 255)

        pHeader.setTextColor(sec)
        pTimer.setTextColor(tc)
        pWhen.setTextColor(sec)
        pSubject.setTextColor(tc)
        pPill.setTextColor(tc)
        pPill.background = rounded(pillBg, 14, pillStroke)
        pNote.background = rounded(pillBg, 14, pillStroke)

        val note = Store.note(this)
        if (note.isBlank()) {
            pNote.visibility = View.GONE
        } else {
            pNote.visibility = View.VISIBLE
            pNote.text = "📝  $note"
            pNote.setTextColor(tc)
        }

        val st = Logic.compute(this)
        pHeader.text = Logic.header(this, st)
        val l = st.lesson
        if (st.kind == Logic.Kind.NONE || l == null) {
            pTimer.visibility = View.GONE
            pWhen.visibility = View.GONE
            pSubject.text = "Расписание не настроено"
            pPill.visibility = View.VISIBLE
            pillShown = ""
            pPill.alpha = 1f
            pPill.text = "Добавь " + Vocabs.cur(this).nomPl + " ниже"
        } else {
            val left = ((st.targetMs - System.currentTimeMillis()) / 1000L).coerceAtLeast(0L)
            val h = left / 3600
            val m = (left % 3600) / 60
            val s = left % 60
            pTimer.visibility = View.VISIBLE
            pTimer.text = Logic.countdownLabel(this, st) + "  " + String.format(Locale.ROOT, "%d:%02d:%02d", h, m, s)
            pWhen.visibility = View.VISIBLE
            pWhen.text = Logic.whenText(st)
            pSubject.text = l.name
            pPill.visibility = View.VISIBLE
            val ord = Logic.ordinal(this, st)
            if (l.place.isBlank()) {
                setPill(ord)
            } else {
                // 5 секунд кабинет, 10 секунд номер урока
                val phase = (System.currentTimeMillis() / 1000L) % 15L
                setPill(if (phase < 5L) l.place else ord)
            }
        }
    }

    // ───────────────────────── действия ─────────────────────────

    private fun pinWidget() {
        val m = AppWidgetManager.getInstance(this)
        if (m.isRequestPinAppWidgetSupported) {
            m.requestPinAppWidget(ComponentName(this, NextLessonWidget::class.java), null, null)
        } else {
            Toast.makeText(
                this,
                "Долго нажми на пустое место рабочего стола → Виджеты → Следующий урок",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun canExact(): Boolean {
        if (Build.VERSION.SDK_INT < 31) return true
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        return am.canScheduleExactAlarms()
    }

    private fun askExactAlarms() {
        if (canExact()) {
            Toast.makeText(this, "Точные обновления уже включены", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            startActivity(
                Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))
            )
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Включи «Будильники и напоминания» в настройках приложения", Toast.LENGTH_LONG).show()
        }
    }

    private fun field(hint: String, value: String): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setText(value)
        e.setHintTextColor(C.MUTED)
        e.setTextColor(Color.WHITE)
        e.textSize = 16f
        e.setSingleLine()
        e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        e.background = rounded(C.CARD2, 14, C.STROKE)
        e.setPadding(dp(14), dp(12), dp(14), dp(12))
        return e
    }

    private fun showLessonDialog(old: Lesson?, index: Int, newKind: Int = 0) {
        val kind = old?.kind ?: newKind
        val voc = if (kind == 1) Vocabs.MEETING else Vocabs.cur(this)
        val list = currentList()
        var start = old?.start ?: if (list.isNotEmpty()) minOf(list.last().end + 10, 23 * 60) else 8 * 60 + 30
        var end = old?.end ?: minOf(start + 45, 23 * 60 + 59)

        val form = LinearLayout(this)
        form.orientation = LinearLayout.VERTICAL
        form.setPadding(dp(18), dp(8), dp(18), dp(4))

        val nameEt = field(voc.hintName, old?.name ?: "")
        val placeEt = field(voc.hintPlace, old?.place ?: "")
        form.addView(nameEt)

        // быстрые варианты для встреч
        if (kind == 1) {
            val chipsScroll = HorizontalScrollView(this)
            chipsScroll.isHorizontalScrollBarEnabled = false
            val chipsRow = LinearLayout(this)
            chipsRow.orientation = LinearLayout.HORIZONTAL
            for (name in listOf("Стоматолог", "Врач", "Банк", "Встреча", "Собеседование", "Парикмахер")) {
                val chip = text(name, 13f, C.ACCENT, true)
                chip.setPadding(dp(12), dp(7), dp(12), dp(7))
                chip.background = rounded(C.CARD2, 14, C.STROKE)
                chip.setOnClickListener {
                    nameEt.setText(name)
                    nameEt.setSelection(name.length)
                }
                val cp = LinearLayout.LayoutParams(WRAP, WRAP)
                cp.rightMargin = dp(6)
                chipsRow.addView(chip, cp)
            }
            chipsScroll.addView(chipsRow)
            form.addView(chipsScroll, lp(8))
        }
        form.addView(placeEt, lp(8))

        // время: одна строка из двух половинок, сразу под названием и местом
        val startTv = text("", 18f, Color.WHITE, true)
        val endTv = text("", 18f, Color.WHITE, true)
        for (t in listOf(startTv, endTv)) {
            t.gravity = Gravity.CENTER
            t.setPadding(dp(8), dp(13), dp(8), dp(13))
        }
        val timeRow = LinearLayout(this)
        timeRow.orientation = LinearLayout.HORIZONTAL
        timeRow.background = rounded(C.CARD2, 14, C.STROKE)
        val divider = View(this)
        divider.setBackgroundColor(C.STROKE)
        timeRow.addView(startTv, LinearLayout.LayoutParams(0, WRAP, 1f))
        timeRow.addView(divider, LinearLayout.LayoutParams(dp(1), MATCH))
        timeRow.addView(endTv, LinearLayout.LayoutParams(0, WRAP, 1f))
        form.addView(timeRow, lp(8))

        fun refreshTimes() {
            startTv.text = "С  " + Logic.hm(start)
            endTv.text = "До  " + Logic.hm(end)
        }
        refreshTimes()

        startTv.setOnClickListener {
            TimePickerDialog(
                this, android.R.style.Theme_Material_Dialog,
                TimePickerDialog.OnTimeSetListener { _: TimePicker, h: Int, m: Int ->
                    start = h * 60 + m
                    if (end <= start) end = minOf(start + 45, 23 * 60 + 59)
                    refreshTimes()
                },
                start / 60, start % 60, true
            ).show()
        }
        endTv.setOnClickListener {
            TimePickerDialog(
                this, android.R.style.Theme_Material_Dialog,
                TimePickerDialog.OnTimeSetListener { _: TimePicker, h: Int, m: Int ->
                    end = h * 60 + m
                    refreshTimes()
                },
                end / 60, end % 60, true
            ).show()
        }

        val where = if (mode == 0) Logic.dm(selDate) else Logic.DAYS_FULL[selDay - 1]
        val b = darkDialog()
            .setTitle(if (old == null) Vocabs.newTitle(voc) + " · $where" else "Изменить " + voc.accSg)
            .setView(form)
            .setPositiveButton("Сохранить", null)
            .setNegativeButton("Отмена", null)
        if (old != null) {
            b.setNeutralButton("Удалить") { _, _ ->
                list.removeAt(index)
                persist(list)
            }
        }
        val dlg = b.create()
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val name = nameEt.text.toString().trim()
                if (name.isEmpty()) {
                    Toast.makeText(this, "Напиши название", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                if (end <= start) {
                    Toast.makeText(this, "Конец должен быть позже начала", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                val item = Lesson(name, placeEt.text.toString().trim(), start, end, kind)
                if (old == null) list.add(item) else list[index] = item
                persist(list)
                dlg.dismiss()
            }
        }
        dlg.show()
    }

    /** Копирование шаблона дня недели на другие дни недели. */
    private fun showCopyDialog() {
        val others = (1..7).filter { it != selDay }
        val checked = BooleanArray(others.size)
        val names = Array<CharSequence>(others.size) { Logic.DAYS_FULL[others[it] - 1] }
        darkDialog()
            .setTitle("Скопировать на (заменит уроки в выбранных днях)")
            .setMultiChoiceItems(names, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("Скопировать") { _, _ ->
                val src = Store.loadDay(this, selDay)
                others.forEachIndexed { i, d -> if (checked[i]) Store.saveDay(this, d, src) }
                WidgetUpdater.updateAll(this)
                Toast.makeText(this, "Готово", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    /** Копирование выбранной даты на другие даты (на месяц вперёд). */
    private fun showCopyDatesDialog() {
        val start = today()
        val dates = (0..30).map { start.plusDays(it.toLong()) }.filter { it != selDate }
        val checked = BooleanArray(dates.size)
        val names = Array<CharSequence>(dates.size) {
            val d = dates[it]
            Logic.DAYS_SHORT[d.dayOfWeek.value - 1] + "  " + Logic.dm(d)
        }
        darkDialog()
            .setTitle("Скопировать на даты (заменит уроки)")
            .setMultiChoiceItems(names, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("Скопировать") { _, _ ->
                val src = Store.loadDate(this, selDate)
                dates.forEachIndexed { i, d -> if (checked[i]) Store.saveDate(this, d, src) }
                WidgetUpdater.updateAll(this)
                renderTabs()
                Toast.makeText(this, "Готово", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun showTzDialog() {
        val now = Instant.now()
        val all = ZoneId.getAvailableZoneIds()
            .filter { it.contains("/") && !it.startsWith("Etc/") && !it.startsWith("SystemV/") }
            .sorted()

        fun label(id: String): String {
            if (id.isEmpty()) return "Как в системе (${ZoneId.systemDefault().id})"
            val off = ZoneId.of(id).rules.getOffset(now).id.let { if (it == "Z") "+00:00" else it }
            return "$id  (UTC$off)"
        }

        val shown = ArrayList<String>()
        val adapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, ArrayList<String>())
        fun filter(q: String) {
            shown.clear()
            shown.add("")
            for (id in all) if (id.contains(q.trim(), ignoreCase = true)) shown.add(id)
            adapter.clear()
            adapter.addAll(shown.map { label(it) })
            adapter.notifyDataSetChanged()
        }

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)
        val search = EditText(this)
        search.hint = "Поиск: Moscow, Paris, Tokyo…"
        search.setSingleLine()
        val lv = ListView(this)
        lv.adapter = adapter
        box.addView(search)
        box.addView(lv, LinearLayout.LayoutParams(MATCH, dp(320)))
        filter("")

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                filter(s?.toString() ?: "")
            }
        })

        var dlg: AlertDialog? = null
        lv.setOnItemClickListener { _, _, pos, _ ->
            Store.setTz(this, shown[pos])
            dlg?.dismiss()
            refreshButtons()
            WidgetUpdater.updateAll(this)
            updatePreview()
        }
        dlg = darkDialog().setTitle("Часовой пояс").setView(box).setNegativeButton("Отмена", null).show()
    }

    // ───────────────────────── цвета ─────────────────────────

    private fun showColorsDialog(forWidget: Boolean) {
        val scroll = ScrollView(this)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(18), dp(8), dp(18), dp(8))
        scroll.addView(box)

        fun render() {
            box.removeAllViews()
            val cur = if (forWidget) Store.grad(this) else Store.uiGrad(this)
            val presets: List<Preset> =
                if (forWidget) Themes.PRESETS
                else listOf(Preset("Классика", C.V1, C.V2)) + Themes.PRESETS.drop(1)

            val prev = View(this)
            prev.background = Themes.drawable(cur, dp(18).toFloat(), dp(1), Color.argb(60, 255, 255, 255))
            box.addView(prev, LinearLayout.LayoutParams(MATCH, dp(70)))

            val hint = text(
                if (forWidget) "Цвет сразу применяется к виджету" else "Меняет цвет самого приложения (кнопки, фон, карточки)",
                12f, C.MUTED
            )
            hint.gravity = Gravity.CENTER
            box.addView(hint, lp(6))

            box.addView(btn("🎨  Создать свой градиент", true) {
                showCustomDialog(cur, forWidget) { render() }
            }, lp(12))

            box.addView(text("Готовые градиенты", 15f, Color.WHITE, true), lp(16))

            val perRow = 4
            var i = 0
            while (i < presets.size) {
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                for (k in 0 until perRow) {
                    val idx = i + k
                    val cellBox = LinearLayout(this)
                    cellBox.orientation = LinearLayout.VERTICAL
                    cellBox.gravity = Gravity.CENTER_HORIZONTAL
                    if (idx < presets.size) {
                        val pr = presets[idx]
                        val selected = cur.c1 == pr.c1 && cur.c2 == pr.c2
                        val sw = View(this)
                        sw.background = Themes.drawable(
                            Grad(pr.c1, pr.c2, 315), dp(14).toFloat(),
                            if (selected) dp(3) else dp(1),
                            if (selected) Color.WHITE else C.STROKE
                        )
                        cellBox.addView(sw, LinearLayout.LayoutParams(MATCH, dp(52)))
                        val nm = text(pr.name, 11f, if (selected) Color.WHITE else C.MUTED, selected)
                        nm.gravity = Gravity.CENTER
                        nm.maxLines = 1
                        cellBox.addView(nm, lp(3))
                        cellBox.setOnClickListener {
                            if (forWidget) {
                                Store.setGrad(this, Grad(pr.c1, pr.c2, 315))
                                WidgetUpdater.updateAll(this)
                            } else {
                                Store.setUiGrad(this, Grad(pr.c1, pr.c2, 0))
                            }
                            render()
                        }
                    }
                    val p = LinearLayout.LayoutParams(0, WRAP, 1f)
                    p.setMargins(dp(4), dp(6), dp(4), dp(4))
                    row.addView(cellBox, p)
                }
                box.addView(row, lp(0))
                i += perRow
            }
        }
        render()

        val dlg = darkDialog()
            .setTitle(if (forWidget) "Цвета виджета" else "Цвета приложения")
            .setView(scroll)
            .setPositiveButton("Готово", null)
            .create()
        dlg.setOnDismissListener {
            // обновляем цвета всего приложения
            build()
        }
        dlg.show()
    }

    private fun showCustomDialog(start: Grad, forWidget: Boolean, onApply: () -> Unit) {
        var c1 = start.c1
        var c2 = start.c2
        var ang = start.angle
        var editing = 0
        var syncing = false
        val arrows = arrayOf("→", "↗", "↑", "↖", "←", "↙", "↓", "↘")

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), dp(4))
        val scroll = ScrollView(this)
        scroll.addView(box)

        val preview = View(this)
        box.addView(preview, LinearLayout.LayoutParams(MATCH, dp(90)))

        val toggles = LinearLayout(this)
        toggles.orientation = LinearLayout.HORIZONTAL
        val b1 = text("Цвет 1", 14f, Color.WHITE, true)
        val b2 = text("Цвет 2", 14f, Color.WHITE, true)
        for (b in listOf(b1, b2)) {
            b.gravity = Gravity.CENTER
            b.setPadding(dp(8), dp(12), dp(8), dp(12))
        }
        val tl1 = LinearLayout.LayoutParams(0, WRAP, 1f)
        tl1.rightMargin = dp(8)
        toggles.addView(b1, tl1)
        toggles.addView(b2, LinearLayout.LayoutParams(0, WRAP, 1f))
        box.addView(toggles, lp(12))

        val sr = SeekBar(this)
        val sg = SeekBar(this)
        val sb = SeekBar(this)
        for (s in listOf(sr, sg, sb)) s.max = 255
        box.addView(text("Красный", 12f, C.MUTED), lp(10))
        box.addView(sr)
        box.addView(text("Зелёный", 12f, C.MUTED), lp(4))
        box.addView(sg)
        box.addView(text("Синий", 12f, C.MUTED), lp(4))
        box.addView(sb)

        val hex = EditText(this)
        hex.hint = "HEX, например FF8800"
        hex.setSingleLine()
        hex.inputType = InputType.TYPE_CLASS_TEXT or
            InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or
            InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        hex.filters = arrayOf(InputFilter.LengthFilter(6))
        box.addView(hex, lp(6))

        val angLabel = text("", 13f, C.MUTED)
        box.addView(angLabel, lp(10))
        val sa = SeekBar(this)
        sa.max = 7
        sa.progress = (((ang % 360) + 360) % 360) / 45
        box.addView(sa)

        val swap = btn("⇄  Поменять цвета местами", false) {}
        box.addView(swap, lp(12))

        fun hexOf(c: Int): String = String.format(Locale.ROOT, "%06X", c and 0xFFFFFF)

        fun styleToggles() {
            val pairs = listOf(Pair(b1, c1), Pair(b2, c2))
            for ((i, pr) in pairs.withIndex()) {
                val (b, c) = pr
                b.background = rounded(c, 12, if (editing == i) Color.WHITE else C.STROKE, if (editing == i) 3 else 1)
                b.setTextColor(if (Themes.lum(c) > 0.35) Color.parseColor("#1A1030") else Color.WHITE)
            }
        }

        fun updPreview() {
            preview.background = Themes.drawable(Grad(c1, c2, ang), dp(18).toFloat(), dp(1), Color.argb(60, 255, 255, 255))
            angLabel.text = "Направление: " + arrows[(((ang % 360) + 360) % 360) / 45]
        }

        fun loadSliders() {
            syncing = true
            val c = if (editing == 0) c1 else c2
            sr.progress = Color.red(c)
            sg.progress = Color.green(c)
            sb.progress = Color.blue(c)
            hex.setText(hexOf(c))
            syncing = false
            styleToggles()
            updPreview()
        }

        fun setColor(c: Int) {
            if (editing == 0) c1 = c else c2 = c
        }

        val sliderListener = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (syncing || !fromUser) return
                val c = Color.rgb(sr.progress, sg.progress, sb.progress)
                setColor(c)
                syncing = true
                hex.setText(hexOf(c))
                syncing = false
                styleToggles()
                updPreview()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        }
        sr.setOnSeekBarChangeListener(sliderListener)
        sg.setOnSeekBarChangeListener(sliderListener)
        sb.setOnSeekBarChangeListener(sliderListener)

        hex.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (syncing) return
                val t = s?.toString() ?: return
                if (t.length != 6) return
                try {
                    val c = Color.parseColor("#$t")
                    setColor(c)
                    syncing = true
                    sr.progress = Color.red(c)
                    sg.progress = Color.green(c)
                    sb.progress = Color.blue(c)
                    syncing = false
                    styleToggles()
                    updPreview()
                } catch (e: IllegalArgumentException) {
                    // не цвет — ждём дальше
                }
            }
        })

        sa.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                ang = p * 45
                updPreview()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        b1.setOnClickListener {
            editing = 0
            loadSliders()
        }
        b2.setOnClickListener {
            editing = 1
            loadSliders()
        }
        swap.setOnClickListener {
            val t = c1
            c1 = c2
            c2 = t
            loadSliders()
        }
        loadSliders()

        darkDialog()
            .setTitle("Свой градиент")
            .setView(scroll)
            .setPositiveButton("Применить") { _, _ ->
                if (forWidget) {
                    Store.setGrad(this, Grad(c1, c2, ang))
                    WidgetUpdater.updateAll(this)
                } else {
                    Store.setUiGrad(this, Grad(c1, c2, ang))
                }
                onApply()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    // ───────────────────────── редактор виджета и режимы ─────────────────────────

    private fun openEditor(tab: Int) {
        startActivity(Intent(this, EditorActivity::class.java).putExtra("tab", tab))
    }

    private fun showVocabDialog() {
        val scroll = ScrollView(this)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(18), dp(8), dp(18), dp(8))
        scroll.addView(box)

        box.addView(
            text("Выбери, что ты ведёшь в расписании. Подписи в приложении и на виджете подстроятся.", 12f, C.MUTED)
        )
        val cur = Vocabs.cur(this)
        var dlg: AlertDialog? = null
        for (v in Vocabs.LIST) {
            val sel = v.id == cur.id
            val fg = if (sel) onPrimary() else Color.WHITE
            val c = LinearLayout(this)
            c.orientation = LinearLayout.VERTICAL
            c.background = if (sel) gradient(16) else rounded(C.CARD2, 16, C.STROKE)
            c.setPadding(dp(14), dp(12), dp(14), dp(12))
            c.addView(text(v.title, 16f, fg, true))
            c.addView(text(v.sub, 12f, if (sel) fg else C.MUTED))
            c.addView(
                text("«" + Vocabs.nextTitle(v) + "», «До " + v.genSg + "»", 12f, if (sel) fg else C.ACCENT),
                lp(4)
            )
            c.setOnClickListener {
                Store.setVocab(this, v.id)
                dlg?.dismiss()
                WidgetUpdater.updateAll(this)
                build()
            }
            box.addView(c, lp(10))
        }
        dlg = darkDialog().setTitle("Режим и подписи").setView(scroll).setNegativeButton("Закрыть", null).show()
    }
}
